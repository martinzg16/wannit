import { safeUrl } from './store.js';
export const financingLabels = {
  product: 'Financiación anunciada para este producto',
  store: 'La tienda anuncia financiación',
  not_detected: 'Financiación no detectada',
  unchecked: 'Financiación sin comprobar'
};
export function renderFinancing(container, detection, { compact = false } = {}) {
  container.replaceChildren();
  const compactState = compact && !['product','store'].includes(detection?.status);
  container.classList.toggle('finance-compact', compactState);
  if (compactState) {
    const chip = document.createElement('span'); chip.className = 'chip finance-chip';
    chip.textContent = detection?.status === 'not_detected' ? 'Financiación no detectada' : 'Financiación sin comprobar';
    chip.title = 'Puede haber opciones al pagar. No se ha confirmado su disponibilidad.';
    container.append(chip); return;
  }
  const add = (parent, tag, text, className) => {
    const node = document.createElement(tag); node.textContent = text;
    if (className) node.className = className;
    parent.append(node); return node;
  };
  add(container, 'p', financingLabels[detection?.status] || financingLabels.unchecked, 'finance-status');
  if (!detection || detection.status === 'unchecked') {
    add(container, 'p', 'Abre el producto y pulsa la extensión para comprobarlo.', 'hint'); return;
  }
  if (detection.status === 'not_detected') {
    add(container, 'p', 'No se encontraron señales en el contenido accesible. Puede haber opciones al pagar.', 'hint');
  } else {
    add(container, 'p', 'Información anunciada; confirma disponibilidad y aprobación al pagar.', 'hint');
    for (const offer of detection.offers || []) {
      const details = add(container, 'details', '');
      add(details, 'summary', offer.provider || 'Ver información encontrada');
      add(details, 'blockquote', offer.evidence);
      const names = { installments: 'Plazo anunciado', installmentAmount: 'Cuota anunciada', upfront: 'Entrada', interest: 'Intereses', total: 'Total publicado' };
      for (const [key, label] of Object.entries(names)) {
        if (offer.terms?.[key]) add(details, 'p', `${label}: ${offer.terms[key]}`, 'hint');
      }
      add(details, 'p', 'Solo se muestran condiciones explícitas; no se combinan ofertas ni se calculan importes ausentes.', 'hint');
      const url = safeUrl(offer.conditionsUrl);
      if (url) { const link = add(details, 'a', 'Consultar fuente ↗', 'shop'); link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer'; }
    }
  }
  add(container, 'p', `Consultado: ${new Date(detection.checkedAt).toLocaleString('es-ES')}`, 'hint');
}
