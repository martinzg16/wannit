export const api = globalThis.browser ?? globalThis.chrome;
export async function readItems() {
  const data = await api.storage.local.get(null);
  return Object.entries(data).filter(([key]) => key.startsWith('item:')).map(([, value]) => value);
}
export async function saveItem(item) { await api.storage.local.set({ ['item:' + item.id]: item }); }
export async function removeItem(id) { await api.storage.local.remove('item:' + id); }
export function safeUrl(value) {
  try { const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) ? u.href : ''; } catch { return ''; }
}
export function money(value, currency) {
  if (value === null || value === undefined) return 'Sin precio';
  try { return new Intl.NumberFormat('es-ES', { style: 'currency', currency }).format(value); }
  catch { return `${Number(value).toFixed(2)} ${currency}`; }
}
