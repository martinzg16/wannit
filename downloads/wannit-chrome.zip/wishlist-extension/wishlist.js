import { api, readItems, saveItem, removeItem, safeUrl, money } from './store.js';
import { renderFinancing } from './financing-ui.js';
import { createChipPicker } from './chip-picker.js';
import { icon, categoryTheme } from './icons.js';
import { categories, categoryOf, categoriesOf, discountOf, matchesCatalog, fillCategories, mountCategoryFields, setCategoryFields, readCategoryFields } from './catalog.js';
const $ = selector => document.querySelector(selector);
let items = [];
let editing;
for (const node of document.querySelectorAll('[data-icon]')) node.append(icon(node.dataset.icon));
for (const button of document.querySelectorAll('[data-help]')) button.onclick = () => $('#help-dialog').showModal();
fillCategories($('#category-filter'), true);
mountCategoryFields($('#edit-form'));
const categoryFilter = createChipPicker($('#category-chips'), { options: categories, label: 'Categorías', onChange: values => { $('#category-filter').value = values[0] || ''; render(); } });
const el = (tag, text, className) => { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; };
const action = (label, fn) => { const button = el('button', label, 'secondary'); button.onclick = async () => { try { await fn(); } catch { $('#status').textContent = 'No se pudo completar la acción.'; } }; return button; };
for (const button of document.querySelectorAll('[data-view]')) button.onclick = () => {
  $('#filter').value = button.dataset.view === 'bought' ? 'bought' : 'pending';
  $('#discount-filter').value = button.dataset.view === 'sale' ? 'discounted' : '';
  $('#category-filter').value = ''; $('#search').value = ''; render();
};
const categoryButtons = [];
for (const category of categories) {
 const button = el('button'); const theme = categoryTheme(category);
 const dot = el('span', undefined, 'category-dot ' + theme.tone);
 const count = el('span', '0', 'nav-count');
 button.append(dot, el('span', category), count);
 button.onclick = () => { $('#category-filter').value = $('#category-filter').value === category ? '' : category; render(); };
 $('#category-nav').append(button); categoryButtons.push({button, category, count});
}
const formatTotals = totals => Object.entries(totals).map(([currency,value]) => money(value,currency)).join(' + ');
async function reload() { items = await readItems(); render(); }
function render() {
  categoryFilter.set($('#category-filter').value ? [$('#category-filter').value] : [], [...new Set(items.flatMap(categoriesOf))]);
  const pending = items.filter(item => !item.purchased);
  const totals = {};
  pending.forEach(item => { if (item.price !== null) totals[item.currency] = (totals[item.currency] || 0) + item.price; });
  $('#total').textContent = Object.entries(totals).map(([currency, value]) => money(value, currency)).join(' + ') || 'Sin precios todavía';
  const unknown = pending.filter(item => item.price === null).length;
  $('#count').textContent = `${pending.length} deseos pendientes${unknown ? ` · ${unknown} sin precio` : ''}`;
  const budget = $('#budget').value;
  const remainder = Number(budget) - (totals.EUR || 0);
  $('#budget-result').textContent = budget === '' ? '' : `${remainder >= 0 ? 'Te quedan' : 'Superas el presupuesto en'} ${money(Math.abs(remainder), 'EUR')}. Solo suma precios conocidos en EUR.`;
  const savings = {}, installments = {};
  for (const item of pending) {
    if (discountOf(item).status === 'discounted') savings[item.currency] = (savings[item.currency] || 0) + item.originalPrice - item.price;
    if (item.months > 0 && Number.isFinite(item.installment)) installments[item.currency] = (installments[item.currency] || 0) + item.installment;
  }
  $('#savings').textContent = formatTotals(savings) || '—';
  $('#savings-note').textContent = `${pending.filter(item => discountOf(item).status === 'discounted').length} ${pending.filter(item => discountOf(item).status === 'discounted').length === 1 ? 'producto con descuento detectado' : 'productos con descuento detectado'}`;
  $('#installments-total').textContent = formatTotals(installments) || '—';
  $('#installments-note').textContent = `${pending.filter(item => item.months > 0 && Number.isFinite(item.installment)).length} planes anotados · plazos independientes`;
  $('#nav-pending').textContent = pending.length;
  $('#nav-bought').textContent = items.length - pending.length;
  $('#nav-sale').textContent = pending.filter(item => discountOf(item).status === 'discounted').length;
  for (const button of document.querySelectorAll('[data-view]')) {
    const currentView = $('#filter').value === 'bought' ? 'bought' : $('#filter').value === 'pending' ? ($('#discount-filter').value === 'discounted' ? 'sale' : 'pending') : 'all';
    const active = currentView === button.dataset.view;
    button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
  }
  for (const entry of categoryButtons) {
    entry.count.textContent = items.filter(item => categoriesOf(item).includes(entry.category)).length;
    entry.button.hidden = Number(entry.count.textContent) === 0 && $('#category-filter').value !== entry.category;
    const active = $('#category-filter').value === entry.category;
    entry.button.classList.toggle('active', active); entry.button.setAttribute('aria-pressed',String(active));
  }
  $('#collection-title').textContent = $('#filter').value === 'bought' ? 'Comprados' : $('#discount-filter').value === 'discounted' ? 'Con descuento' : 'Tu colección';
  const query = $('#search').value.toLocaleLowerCase('es');
  const filtered = items.filter(item => matchesCatalog(item, $('#category-filter').value, $('#discount-filter').value) && (`${item.title} ${item.url} ${item.notes}`).toLocaleLowerCase('es').includes(query) && ($('#filter').value === 'all' || item.purchased === ($('#filter').value === 'bought')));
  filtered.sort($('#sort').value === 'price' ? (a, b) => a.currency.localeCompare(b.currency) || (a.price ?? Infinity) - (b.price ?? Infinity) : (a, b) => b.createdAt.localeCompare(a.createdAt));
  $('#result-count').textContent = `${filtered.length} ${filtered.length === 1 ? 'producto' : 'productos'}`;
  $('#items').replaceChildren();
  $('#empty').hidden = filtered.length > 0;
  const hasFilter = Boolean(query || $('#category-filter').value || $('#discount-filter').value || $('#filter').value === 'bought');
  const noMatches = items.length > 0 || hasFilter;
  $('#empty h2').textContent = noMatches ? 'No hay productos aquí todavía.' : 'Tu próximo hallazgo empieza aquí.';
  $('#empty p').textContent = noMatches ? 'Prueba otra búsqueda o limpia los filtros para ver tus guardados.' : 'Abre un producto en una tienda y pulsa el icono de la extensión para guardarlo.';
  $('#empty [data-help]').hidden = noMatches;
  $('#reset-filters').hidden = !noMatches;
  for (const item of filtered) {
    const category = categoryOf(item), theme = categoryTheme(category), discount = discountOf(item);
    const card = el('article', undefined, 'card');
    const visual = el('div', undefined, 'visual ' + theme.tone);
    const symbol = el('span', undefined, 'visual-symbol'); symbol.append(icon(theme.icon)); visual.append(symbol);
    if (safeUrl(item.image)) { const img = el('img'); img.src = safeUrl(item.image); img.alt = item.title; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer'; img.onerror = () => img.remove(); visual.append(img); }
    visual.append(el('span', category, 'visual-category')); if (discount.status === 'discounted') visual.append(el('span', `−${discount.percent.toLocaleString('es-ES')} %`, 'offer-badge')); card.append(visual);
    const body = el('div', undefined, 'card-body');
    let host = ''; try { host = new URL(item.url).hostname.replace(/^www\./, ''); } catch {}
    const top = el('div',undefined,'card-top');
    top.append(el('p',host,'eyebrow'),el('span',item.purchased ? 'En tu colección' : discount.status === 'discounted' ? 'Con descuento' : category,'category-badge'));
    const title = el('h2');
    const titleButton = el('button',item.title,'product-title'); titleButton.onclick = () => showDetail(item);
    title.append(titleButton); body.append(top,title);
    const openVisual = el('button',undefined,'open-visual'); openVisual.setAttribute('aria-label',`Ver ${item.title}`); openVisual.onclick = () => showDetail(item); visual.append(openVisual);
    const categoryTags = el('div', undefined, 'category-tags');
    for (const name of categoriesOf(item)) categoryTags.append(el('span', name, 'category-badge'));
    body.append(categoryTags);
    const priceLine = el('div',undefined,'price-line'); priceLine.append(el('p',money(item.price,item.currency),'price'));
    if (discount.status === 'discounted') { const sale = el('p',undefined,'sale'); sale.append(el('del',money(item.originalPrice,item.currency)),el('strong',`−${discount.percent.toLocaleString('es-ES')} %`)); priceLine.append(sale); }
    body.append(priceLine);
    const plan = el('p',undefined,'card-finance'); plan.append(icon('wallet'));
    const planText = item.months && item.installment !== null && item.installment !== undefined ? `${money(item.installment,item.currency)} × ${item.months} cuotas anotadas` : ['product','store'].includes(item.financingDetection?.status) ? 'La tienda anuncia financiación' : 'Financiación sin confirmar';
    plan.append(el('span',planText)); body.append(plan);
    const details = el('details',undefined,'card-details'); details.append(el('summary','Detalles y financiación'));
    if (discount.status !== 'discounted') details.append(el('p',discount.status === 'unchecked' ? 'Descuento sin comprobar' : 'Sin descuento detectado','hint'));
    if (item.discountCheckedAt) details.append(el('p',`Precio revisado: ${new Date(item.discountCheckedAt).toLocaleDateString('es-ES')}`,'hint'));
    const financePanel=el('section',undefined,'finance-detection'); renderFinancing(financePanel,item.financingDetection); details.append(financePanel);
    if (item.months && item.installment !== null) details.append(el('p',`Entrada/gastos: ${money(item.upfront,item.currency)} · Total anotado: ${money(item.months * item.installment + item.upfront,item.currency)}`,'finance'));
    if (item.financingNotes) details.append(el('p',item.financingNotes,'hint'));
    if (item.notes) details.append(el('p',item.notes,'notes'));
    details.append(el('p',`Guardado el ${new Date(item.createdAt).toLocaleDateString('es-ES')}${item.updatedAt ? ' · editado' : ''}`,'hint')); body.append(details);
    const footer=el('div',undefined,'card-footer');
    const link=el('a',undefined,'shop'); link.append(icon('external'),el('span','Ir a la tienda')); link.href=safeUrl(item.url); link.target='_blank';link.rel='noopener noreferrer';footer.append(link);
    const actions=el('div',undefined,'actions');
    const purchase=action(item.purchased?'Volver a pendientes':'Marcar comprado',async()=>{await saveItem({...item,purchased:!item.purchased});await reload();});
    const edit=action('Editar',()=>{editing=item; const f=$('#edit-form');for(const name of ['title','price','originalPrice','notes'])f.elements[name].value=item[name]??'';setCategoryFields(f,categoriesOf(item));$('#edit-error').textContent='';$('#edit').showModal();});
    const remove=action('Eliminar',async()=>{if(confirm(`¿Eliminar «${item.title}» de tu wishlist?`)){await removeItem(item.id);await reload();}});
    for(const [button,name] of [[purchase,'check'],[edit,'edit'],[remove,'trash']]) { const label=button.textContent;button.setAttribute('aria-label',label);button.title=label;button.replaceChildren(icon(name));actions.append(button); }
    footer.append(actions);body.append(footer);card.append(body);$('#items').append(card);
  }
}
function showDetail(item) {
 const content = $('#detail-content'); content.replaceChildren();
 const photo = el('div',undefined,'detail-photo'); photo.append(icon(categoryTheme(categoryOf(item)).icon));
 if(safeUrl(item.image)) {const img=el('img');img.src=safeUrl(item.image);img.alt=item.title;img.referrerPolicy='no-referrer';img.onerror=()=>img.remove();photo.append(img);}
 const info=el('div',undefined,'detail-info');
 let host=''; try{host=new URL(item.url).hostname.replace(/^www\./,'');}catch{}
 const title=el('h2',item.title);title.id='detail-title';info.append(el('p',host,'eyebrow'),title);
 const prices=el('div',undefined,'price-line');prices.append(el('p',money(item.price,item.currency),'price'));
 if(discountOf(item).status==='discounted')prices.append(el('del',money(item.originalPrice,item.currency),'hint'));
 info.append(prices);
 const shop=el('a','Ir a la tienda ↗','shop');shop.href=safeUrl(item.url);shop.target='_blank';shop.rel='noopener noreferrer';info.append(shop);
 const cats=el('div',undefined,'category-tags'); for(const c of categoriesOf(item))cats.append(el('span',c,'category-badge'));info.append(cats);
 const finance=el('section',undefined,'finance-detection');renderFinancing(finance,item.financingDetection,{compact:true});info.append(finance);
 if(item.months && Number.isFinite(item.installment))info.append(el('p',`${money(item.installment,item.currency)} × ${item.months} cuotas anotadas`,'hint'));
 if(item.notes)info.append(el('p',item.notes,'notes'));
 info.append(el('p',`Guardado el ${new Date(item.createdAt).toLocaleDateString('es-ES')}. Precio de la última captura.`,'hint'));
 content.append(photo,info);$('#product-detail').showModal();
}
$('#close-detail').onclick=()=>$('#product-detail').close();
$('#reset-filters').onclick = () => { $('#search').value = ''; $('#category-filter').value = ''; $('#discount-filter').value = ''; $('#filter').value = 'all'; render(); $('#search').focus(); };
$('#cancel').onclick = () => $('#edit').close();
$('#edit-form').onsubmit = async event => {
  event.preventDefault(); const values = Object.fromEntries(new FormData(event.target));
  if (!values.title.trim()) return;
  const price = values.price === '' ? null : Number(values.price);
  const originalPrice = values.originalPrice === '' ? null : Number(values.originalPrice);
  if (originalPrice !== null && (price === null || originalPrice < price)) { $('#edit-error').textContent = 'El precio original debe ser igual o mayor que el actual.'; return; }
  try { await saveItem({ ...editing, ...values, categories: readCategoryFields(event.target), category: readCategoryFields(event.target)[0] || 'Sin categorizar', originalPrice, discountCheckedAt: originalPrice !== (editing.originalPrice ?? null) || price !== editing.price ? new Date().toISOString() : editing.discountCheckedAt ?? null, title: values.title.trim(), price: values.price === '' ? null : Number(values.price), updatedAt: new Date().toISOString() }); $('#edit').close(); await reload(); }
  catch { $('#status').textContent = 'No se pudieron guardar los cambios.'; }
};
for (const id of ['search', 'filter', 'sort', 'category-filter', 'discount-filter']) $('#' + id).addEventListener('input', render);
$('#budget').addEventListener('change', async () => { if (!$('#budget').checkValidity()) return; try { await api.storage.local.set({ budget: $('#budget').value }); render(); } catch { $('#status').textContent = 'No se pudo guardar el presupuesto.'; } });
$('#export').onclick = () => {
  const blob = new Blob([JSON.stringify({ version: 1, items, budget: $('#budget').value }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const a = el('a'); a.href = url; a.download = 'mi-wishlist.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
};
api.storage.onChanged.addListener(() => { reload().catch(() => { $('#status').textContent = 'No se pudo actualizar la lista.'; }); });
try { const data = await api.storage.local.get('budget'); $('#budget').value = data.budget ?? ''; await reload(); }
catch { $('#status').textContent = 'No se pudo cargar la wishlist.'; }
