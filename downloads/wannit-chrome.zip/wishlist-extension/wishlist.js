import {readTracking,mountAlertControl,cardAlert,openInbox,when} from './alert-ui.js';
import {effectiveItem} from './alert-core.js';
import { readLists, moveItems, listLabel } from './lists.js';
import { listPicker } from './list-picker.js';
import { openDialog, enter } from './motion.js';
import { api, readItems, saveItem, removeItem, safeUrl, money } from './store.js';
import { createChipPicker } from './chip-picker.js';
import { icon, categoryTheme } from './icons.js';
import { categories, categoryOf, categoriesOf, discountOf, matchesCatalog, fillCategories, mountCategoryFields, setCategoryFields, readCategoryFields } from './catalog.js';
const $ = selector => document.querySelector(selector);
let items = [], lists = [], page = new URLSearchParams(location.search).get('view')==='lists'?'lists':'products';
let activeList = new URLSearchParams(location.search).get('list') || null;
let selecting = false;
const selectedIds = new Set();
let editing;
let tracks = {}, onlyTracking=false, detailItemId=null;
for (const node of document.querySelectorAll('[data-icon]')) node.append(icon(node.dataset.icon));
for (const button of document.querySelectorAll('[data-help]')) button.onclick = () => openDialog($('#help-dialog'));
fillCategories($('#category-filter'), true);
mountCategoryFields($('#edit-form'));
const categoryFilter = createChipPicker($('#category-chips'), { options: categories, label: 'Categorías', onChange: values => { $('#category-filter').value = values[0] || ''; render(); } });
const el = (tag, text, className) => { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; };
const action = (label, fn) => { const button = el('button', label, 'secondary'); button.onclick = async () => { try { await fn(); } catch { $('#status').textContent = 'No se pudo completar la acción.'; } }; return button; };
for (const button of document.querySelectorAll('[data-view]')) button.onclick = () => {
  page = 'products'; activeList = null; selecting = false; selectedIds.clear();
  $('#filter').value = button.dataset.view === 'bought' ? 'bought' : 'pending';
  $('#discount-filter').value = button.dataset.view === 'sale' ? 'discounted' : '';
  $('#category-filter').value = ''; $('#search').value = ''; render();
};
const categoryButtons = [];
for (const category of categories) {
 const button = el('button'); const theme = categoryTheme(category);
 const dot = el('span', undefined, 'category-dot ' + theme.tone);
 const count = el('span', '0', 'nav-count');
 button.append(dot, el('span', category), count);
 button.onclick = () => { $('#category-filter').value = $('#category-filter').value === category ? '' : category; render(); };
 $('#category-nav').append(button); categoryButtons.push({button, category, count});
}
const formatTotals = totals => Object.entries(totals).map(([currency,value]) => money(value,currency)).join(' + ');
async function reload() {
 [items,lists,tracks] = await Promise.all([readItems(),readLists(),readTracking()]); render();
 if($('#product-detail').open && detailItemId){
  const item=items.find(i=>i.id===detailItemId);
  if(!item){$('#product-detail').close();return;}
  mountAlertControl($('#detail-alert'),item,{track:tracks[item.id],history:true});
  const displayed=effectiveItem(item,tracks[item.id]);$('#detail-current-price').textContent=money(displayed.price,displayed.currency);if(displayed!==item)$('#detail-current-price').parentElement.querySelector('del')?.remove();
 }
}
function render() {
  const activeTracks=Object.values(tracks).filter(t=>t.enabled && items.some(i=>i.id===t.id && !i.purchased));
  const unread=Object.values(tracks).reduce((n,t)=>n+t.events.filter(e=>!e.read).length,0);
  $('#tracking-summary').textContent=activeTracks.length?`SIGUIENDO ${activeTracks.length} ${activeTracks.length===1?'PRECIO':'PRECIOS'}`:'SIGUE LO QUE TE GUSTA';
  const errors=activeTracks.filter(t=>['error','permission','confirming'].includes(t.status)).length;
  $('#tracking-note').textContent=activeTracks.length?`Una comprobación diaria con Chrome abierto${errors?` · ${errors} pendientes de actualizar`:''}.`:'Activa una alerta en el detalle. Nike España y Everyday Better Club.';
  $('#alert-unread').textContent=unread;$('#filter-tracking').setAttribute('aria-pressed',String(onlyTracking));
  const route=new URL(location.href);route.searchParams.delete('list');route.searchParams.delete('view');
  if(page==='lists')route.searchParams.set('view','lists');else if(activeList)route.searchParams.set('list',activeList);
  if(route.href!==location.href)history.replaceState(null,'',route);
  if(activeList && !lists.some(list=>list.id===activeList))activeList=null;
  $('#lists-view').hidden=page!=='lists';$('#products-view').hidden=page==='lists';
  $('#nav-lists-count').textContent=lists.length;$('#nav-lists').classList.toggle('active',page==='lists');$('#nav-lists').setAttribute('aria-pressed',String(page==='lists'));
  $('#list-context').hidden=!activeList;$('#view-title').textContent=activeList?listLabel(lists,activeList):'TUS GUARDADOS';
  renderLists();
  for(const id of selectedIds)if(!items.some(item=>item.id===id))selectedIds.delete(id);
  $('#toggle-selection').textContent=selecting?'Cancelar selección':'Seleccionar productos';$('#toggle-selection').setAttribute('aria-pressed',String(selecting));
  $('#move-selected').hidden=!selecting;$('#move-selected').disabled=selectedIds.size===0;$('#selected-count').textContent=selecting?`${selectedIds.size} seleccionados`:'';
  $('.summary').setAttribute('aria-label',activeList?'Resumen de pendientes de '+listLabel(lists,activeList):'Resumen de todos tus pendientes');
  categoryFilter.set($('#category-filter').value ? [$('#category-filter').value] : [], [...new Set(items.filter(item=>!activeList || item.listId===activeList).flatMap(categoriesOf))]);
  const allPending = items.filter(item => !item.purchased).map(item=>effectiveItem(item,tracks[item.id]));
  const pending = allPending.filter(item=>!activeList || item.listId===activeList);
  const totals = {};
  pending.forEach(item => { if (item.price !== null) totals[item.currency] = (totals[item.currency] || 0) + item.price; });
  $('#total').textContent = Object.entries(totals).map(([currency, value]) => money(value, currency)).join(' + ') || 'Sin precios todavía';
  const unknown = pending.filter(item => item.price === null).length;
  $('#count').textContent = `${pending.length} ${pending.length===1?'deseo pendiente':'deseos pendientes'}${unknown ? ` · ${unknown} sin precio` : ''}`;
  const budget = $('#budget').value;
  const budgetTotal=allPending.filter(item=>item.currency==='EUR').reduce((sum,item)=>sum+(Number(item.price)||0),0);
  const remainder = Number(budget) - budgetTotal;
  $('#budget-result').textContent = budget === '' ? '' : `${remainder >= 0 ? 'Te quedan' : 'Superas el presupuesto en'} ${money(Math.abs(remainder), 'EUR')}. Presupuesto global: suma todos tus pendientes en EUR.`;
  const savings = {};
  for (const item of pending) {
    if (discountOf(item).status === 'discounted') savings[item.currency] = (savings[item.currency] || 0) + item.originalPrice - item.price;
  }
  $('#savings').textContent = formatTotals(savings) || '—';
  $('#savings-note').textContent = `${pending.filter(item => discountOf(item).status === 'discounted').length} ${pending.filter(item => discountOf(item).status === 'discounted').length === 1 ? 'producto con descuento detectado' : 'productos con descuento detectado'}`;
  $('#nav-pending').textContent = allPending.length;
  $('#nav-bought').textContent = items.length - allPending.length;
  $('#nav-sale').textContent = allPending.filter(item => discountOf(item).status === 'discounted').length;
  for (const button of document.querySelectorAll('[data-view]')) {
    const currentView = $('#filter').value === 'bought' ? 'bought' : $('#filter').value === 'pending' ? ($('#discount-filter').value === 'discounted' ? 'sale' : 'pending') : 'all';
    const active = page==='products' && !activeList && currentView === button.dataset.view;
    button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
  }
  for (const entry of categoryButtons) {
    entry.count.textContent = items.filter(item => categoriesOf(item).includes(entry.category)).length;
    entry.button.hidden = Number(entry.count.textContent) === 0 && $('#category-filter').value !== entry.category;
    const active = $('#category-filter').value === entry.category;
    entry.button.classList.toggle('active', active); entry.button.setAttribute('aria-pressed',String(active));
  }
  $('#collection-title').textContent = $('#filter').value === 'bought' ? 'Comprados' : $('#discount-filter').value === 'discounted' ? 'Con descuento' : 'Tu colección';
  const query = $('#search').value.toLocaleLowerCase('es');
  const filtered = items.filter(item => (!onlyTracking || tracks[item.id]?.enabled) && (!activeList || item.listId===activeList) && matchesCatalog(item, $('#category-filter').value, $('#discount-filter').value) && (`${item.title} ${item.url} ${item.notes}`).toLocaleLowerCase('es').includes(query) && ($('#filter').value === 'all' || item.purchased === ($('#filter').value === 'bought')));
  filtered.sort($('#sort').value === 'price' ? (a, b) => a.currency.localeCompare(b.currency) || (a.price ?? Infinity) - (b.price ?? Infinity) : (a, b) => b.createdAt.localeCompare(a.createdAt));
  $('#result-count').textContent = `${filtered.length} ${filtered.length === 1 ? 'producto' : 'productos'}`;
  $('#items').replaceChildren();
  $('#empty').hidden = filtered.length > 0;
  const hasFilter = Boolean(onlyTracking || query || $('#category-filter').value || $('#discount-filter').value || $('#filter').value === 'bought');
  const scopeItems = activeList ? items.filter(item=>item.listId===activeList) : items;
  const noMatches = scopeItems.length > 0 || hasFilter;
  $('#empty h2').textContent = noMatches ? 'No hay productos aquí todavía.' : 'Tu próximo hallazgo empieza aquí.';
  $('#empty p').textContent = noMatches ? 'Prueba otra búsqueda o limpia los filtros para ver tus guardados.' : activeList ? 'Guarda un producto desde la extensión eligiendo esta lista, o mueve aquí tus productos desde Guardados.' : 'Abre un producto en una tienda y pulsa el icono de la extensión para guardarlo.';
  $('#empty [data-help]').hidden = noMatches;
  $('#reset-filters').hidden = !noMatches;
  for (const item of filtered) {
    const shown=effectiveItem(item,tracks[item.id]);
    const category = categoryOf(item), theme = categoryTheme(category), discount = discountOf(shown);
    const card = el('article', undefined, 'card'); card.classList.toggle('is-selected',selectedIds.has(item.id));
    const visual = el('div', undefined, 'visual ' + theme.tone);
    const symbol = el('span', undefined, 'visual-symbol'); symbol.append(icon(theme.icon)); visual.append(symbol);
    if (safeUrl(item.image)) { const img = el('img'); img.src = safeUrl(item.image); img.alt = item.title; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer'; img.onerror = () => img.remove(); visual.append(img); }
    visual.append(el('span', category, 'visual-category')); if (discount.status === 'discounted') visual.append(el('span', `−${discount.percent.toLocaleString('es-ES')} %`, 'offer-badge')); card.append(visual);
    const body = el('div', undefined, 'card-body');
    let host = ''; try { host = new URL(item.url).hostname.replace(/^www\./, ''); } catch {}
    const top = el('div',undefined,'card-top');
    top.append(el('p',host,'eyebrow'),el('span',item.purchased ? 'En tu colección' : discount.status === 'discounted' ? 'Con descuento' : category,'category-badge'));
    const title = el('h2');
    const titleButton = el('button',item.title,'product-title'); titleButton.onclick = () => showDetail(item);
    title.append(titleButton); body.append(top,title);
    const openVisual = el('button',undefined,'open-visual'); openVisual.setAttribute('aria-label',`Ver ${item.title}`); openVisual.onclick = () => showDetail(item); visual.append(openVisual);
    if(selecting){const choose=el('input',undefined,'item-select');choose.type='checkbox';choose.checked=selectedIds.has(item.id);choose.setAttribute('aria-label',`Seleccionar ${item.title}`);choose.onchange=()=>{if(choose.checked)selectedIds.add(item.id);else selectedIds.delete(item.id);card.classList.toggle('is-selected',choose.checked);$('#selected-count').textContent=`${selectedIds.size} seleccionados`;$('#move-selected').disabled=selectedIds.size===0;};visual.append(choose);} 
    const categoryTags = el('div', undefined, 'category-tags');
    for (const name of categoriesOf(item)) categoryTags.append(el('span', name, 'category-badge'));
    if(item.listId)categoryTags.append(el('span',listLabel(lists,item.listId),'list-tag'));body.append(categoryTags);
    const priceLine = el('div',undefined,'price-line'); priceLine.append(el('p',money(shown.price,shown.currency),'price'));
    if (discount.status === 'discounted') { const sale = el('p',undefined,'sale'); sale.append(el('del',money(item.originalPrice,item.currency)),el('strong',`−${discount.percent.toLocaleString('es-ES')} %`)); priceLine.append(sale); }
    body.append(priceLine,cardAlert(item,tracks[item.id]));
    const details = el('details',undefined,'card-details'); details.append(el('summary','Detalles'));
    if (discount.status !== 'discounted') details.append(el('p',discount.status === 'unchecked' ? 'Descuento sin comprobar' : 'Sin descuento detectado','hint'));
    if (item.discountCheckedAt) details.append(el('p',`Precio revisado: ${new Date(item.discountCheckedAt).toLocaleDateString('es-ES')}`,'hint'));
    if (item.notes) details.append(el('p',item.notes,'notes'));
    details.append(el('p',`Guardado el ${new Date(item.createdAt).toLocaleDateString('es-ES')}${item.updatedAt ? ' · editado' : ''}`,'hint')); body.append(details);
    const footer=el('div',undefined,'card-footer');
    const link=el('a',undefined,'shop'); link.append(icon('external'),el('span','Ir a la tienda')); link.href=safeUrl(item.url); link.target='_blank';link.rel='noopener noreferrer';footer.append(link);
    const actions=el('div',undefined,'actions');
    const purchase=action(item.purchased?'Volver a pendientes':'Marcar comprado',async()=>{await saveItem({...item,purchased:!item.purchased});await reload();});
    const edit=action('Editar',()=>{editing=item; const f=$('#edit-form');for(const name of ['title','price','originalPrice','notes'])f.elements[name].value=item[name]??'';setCategoryFields(f,categoriesOf(item));$('#edit-error').textContent='';openDialog($('#edit'));});
    const remove=action('Eliminar',async()=>{if(confirm(`¿Eliminar «${item.title}» de tu wishlist?`)){await removeItem(item.id);await reload();}});
    for(const [button,name] of [[purchase,'check'],[edit,'edit'],[remove,'trash']]) { const label=button.textContent;button.setAttribute('aria-label',label);button.title=label;button.replaceChildren(icon(name));actions.append(button); }
    const move=action('Mover a lista',()=>chooseDestination([item.id],item.listId));move.classList.add('move-item');footer.append(actions,move);body.append(footer);card.append(body);$('#items').append(card);
  }
}
function showDetail(item) {
 detailItemId=item.id;const shown=effectiveItem(item,tracks[item.id]);
 const content = $('#detail-content'); content.replaceChildren();
 const photo = el('div',undefined,'detail-photo'); photo.append(icon(categoryTheme(categoryOf(item)).icon));
 if(safeUrl(item.image)) {const img=el('img');img.src=safeUrl(item.image);img.alt=item.title;img.referrerPolicy='no-referrer';img.onerror=()=>img.remove();photo.append(img);}
 const info=el('div',undefined,'detail-info');
 let host=''; try{host=new URL(item.url).hostname.replace(/^www\./,'');}catch{}
 const title=el('h2',item.title);title.id='detail-title';info.append(el('p',host,'eyebrow'),title);
 const prices=el('div',undefined,'price-line');const currentPrice=el('p',money(shown.price,shown.currency),'price');currentPrice.id='detail-current-price';prices.append(currentPrice);
 if(discountOf(shown).status==='discounted')prices.append(el('del',money(item.originalPrice,item.currency),'hint'));
 info.append(prices);
 const alertPanel=el('div');alertPanel.id='detail-alert';mountAlertControl(alertPanel,item,{track:tracks[item.id],history:true});info.append(alertPanel);
 const shop=el('a','Ir a la tienda ↗','shop');shop.href=safeUrl(item.url);shop.target='_blank';shop.rel='noopener noreferrer';info.append(shop);
 const cats=el('div',undefined,'category-tags'); for(const c of categoriesOf(item))cats.append(el('span',c,'category-badge'));info.append(cats);
 if(item.notes)info.append(el('p',item.notes,'notes'));
 info.append(el('p',`Guardado el ${new Date(item.createdAt).toLocaleDateString('es-ES')}. Precio de la última captura o comprobación automática válida.`,'hint'));
 const move=action('Mover a otra lista',()=>{$('#product-detail').close();chooseDestination([item.id],item.listId);});move.classList.add('detail-move');info.append(move);
 content.append(photo,info);openDialog($('#product-detail'));
}
function showLists(){page='lists';activeList=null;$('#status').textContent='';selecting=false;selectedIds.clear();render();enter($('#lists-grid'),'view');}
function openList(id){$('#status').textContent='';activeList=id;page='products';selecting=false;selectedIds.clear();$('#filter').value='all';$('#category-filter').value='';$('#discount-filter').value='';$('#search').value='';render();}
function newList(){listPicker({createOnly:true,onConfirm:async id=>{await reload();openList(id);}});}
function chooseDestination(ids,current=null){listPicker({title:'Mover a lista',current:current||null,confirmText:'Mover aquí',createText:'Crear y mover',onConfirm:async id=>{await moveItems(ids,id);selectedIds.clear();selecting=false;await reload();$('#status').textContent=`${ids.length} ${ids.length===1?'producto movido':'productos movidos'} a ${listLabel(lists,id)}.`;}});}
function renderLists(){
 const grid=$('#lists-grid');grid.replaceChildren();$('#lists-empty').hidden=lists.length>0;
 for(const [index,list] of lists.entries()){
  const members=items.filter(item=>item.listId===list.id),card=el('article',undefined,'list-card'),button=el('button',undefined,'list-card-open');
  button.setAttribute('aria-label',`Abrir lista ${list.name}`);button.onclick=()=>openList(list.id);
  const cover=el('div',undefined,'list-cover');const photographs=members.filter(item=>safeUrl(item.image)).slice(0,3);
  if(photographs.length){for(const item of photographs){const img=el('img');img.src=safeUrl(item.image);img.alt='';img.referrerPolicy='no-referrer';img.onerror=()=>{img.onerror=null;img.src='illustrations/'+['chair','shoe','headphones','lamp'][index%4]+'.svg';};cover.append(img);}}
  else{const img=el('img');img.src='illustrations/'+['chair','shoe','headphones','lamp'][index%4]+'.svg';img.alt='';cover.classList.add('illustrated');cover.append(img);}
  const saleCount=members.filter(item=>discountOf(item).status==='discounted').length;
  button.append(cover,el('h2',list.name),el('p',`${members.length} ${members.length===1?'producto':'productos'}${saleCount?' · '+saleCount+' en oferta':''}`,'hint'));card.append(button);grid.append(card);
 }
}
$('#filter-tracking').onclick=()=>{onlyTracking=!onlyTracking;render();};
$('#open-alerts').onclick=()=>openInbox(items,tracks).catch(()=>{$('#status').textContent='No se pudo abrir la bandeja.';});
$('#nav-lists').onclick=showLists;$('#back-to-lists').onclick=showLists;$('#new-list').onclick=newList;$('#first-list').onclick=newList;
$('#rename-list').onclick=()=>{const list=lists.find(list=>list.id===activeList);if(list)listPicker({renaming:list,onConfirm:reload});};
$('#toggle-selection').onclick=()=>{selecting=!selecting;selectedIds.clear();render();};
$('#move-selected').onclick=()=>chooseDestination([...selectedIds]);
$('#close-detail').onclick=()=>$('#product-detail').close();
$('#reset-filters').onclick = () => { onlyTracking=false; $('#search').value = ''; $('#category-filter').value = ''; $('#discount-filter').value = ''; $('#filter').value = 'all'; render(); $('#search').focus(); };
$('#cancel').onclick = () => $('#edit').close();
$('#edit-form').onsubmit = async event => {
  event.preventDefault(); const values = Object.fromEntries(new FormData(event.target));
  if (!values.title.trim()) return;
  const price = values.price === '' ? null : Number(values.price);
  const originalPrice = values.originalPrice === '' ? null : Number(values.originalPrice);
  if (originalPrice !== null && (price === null || originalPrice < price)) { $('#edit-error').textContent = 'El precio original debe ser igual o mayor que el actual.'; return; }
  try { await saveItem({ ...editing, ...values, categories: readCategoryFields(event.target), category: readCategoryFields(event.target)[0] || 'Sin categorizar', originalPrice, discountCheckedAt: originalPrice !== (editing.originalPrice ?? null) || price !== editing.price ? new Date().toISOString() : editing.discountCheckedAt ?? null, title: values.title.trim(), price: values.price === '' ? null : Number(values.price), updatedAt: new Date().toISOString() }); $('#edit').close(); await reload(); }
  catch { $('#status').textContent = 'No se pudieron guardar los cambios.'; }
};
for (const id of ['search', 'filter', 'sort', 'category-filter', 'discount-filter']) $('#' + id).addEventListener('input', render);
$('#budget').addEventListener('change', async () => { if (!$('#budget').checkValidity()) return; try { await api.storage.local.set({ budget: $('#budget').value }); render(); } catch { $('#status').textContent = 'No se pudo guardar el presupuesto.'; } });
$('#export').onclick = () => {
  const blob = new Blob([JSON.stringify({ version: 3, lists, items, tracking: tracks, budget: $('#budget').value }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const a = el('a'); a.href = url; a.download = 'mi-wishlist.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
};
api.storage.onChanged.addListener(() => { reload().catch(() => { $('#status').textContent = 'No se pudo actualizar la lista.'; }); });
if(activeList)$('#filter').value='all';
try { const data = await api.storage.local.get('budget'); $('#budget').value = data.budget ?? ''; await reload(); }
catch { $('#status').textContent = 'No se pudo cargar la wishlist.'; }
