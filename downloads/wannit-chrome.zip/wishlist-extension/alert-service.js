import {shopFor,readHTML} from './alert-readers.js';
import {createTracking,applyQuote,failTracking,errorText} from './alert-core.js';
export function createAlertService(api,{fetcher=fetch,now=Date.now}={}) {
  let tail=Promise.resolve(), ticking=false;
  const locked=fn=>{const next=tail.then(fn);tail=next.catch(()=>{});return next;};
  const get=async key=>(await api.storage.local.get(key))[key];
  const put=async track=>api.storage.local.set({['tracking:'+track.id]:track});
  const list=async()=>Object.entries(await api.storage.local.get(null)).filter(([k])=>k.startsWith('tracking:')).map(([,v])=>v);
  const itemFor=async id=>{const item=await get('item:'+id);if(!item)throw new Error('missing');if(item.purchased)throw new Error('purchased');return item;};
  async function read(url) {
    const shop=shopFor(url);if(!shop)throw new Error('unsupported');
    if(!await api.permissions.contains({origins:[shop.origin]}))throw new Error('permission');
    await locked(async()=>{
      const key='alertHost:'+new URL(shop.url).hostname,last=await get(key);
      if(last && now()-last<60000)throw new Error('cooldown');
      await api.storage.local.set({[key]:now()});
    });
    try {
      const response=await fetcher(shop.url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(18000)});
      if(!response.ok)throw new Error('network');
      if(!/text\/html/i.test(response.headers.get('content-type')||''))throw new Error('unreadable');
      const MAX=6*1024*1024;
      if(Number(response.headers.get('content-length'))>MAX)throw new Error('unreadable');
      const reader=response.body.getReader();let size=0,text='';const decoder=new TextDecoder();
      while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>MAX){await reader.cancel();throw new Error('unreadable');}text+=decoder.decode(part.value,{stream:true});}
      text+=decoder.decode();return readHTML(text,shop.url);
    } catch(e){if(['unreadable','ambiguous','variant'].includes(e.message))throw e;throw new Error('network');}
  }
  async function probe(url,currency) {
    const comparable=(await read(url)).filter(q=>q.currency===currency);
    if(!comparable.length)throw new Error('currency');
    const quotes=comparable.filter(q=>q.available!==false);
    if(!quotes.length)throw new Error('unavailable');
    const token=crypto.randomUUID();
    // Session storage survives worker suspension, but never becomes a price history.
    await locked(async()=>{
      const data=await api.storage.session.get('alertProbes'),probes=data.alertProbes||{};
      for(const [id,p] of Object.entries(probes))if(now()-p.at>10*60000)delete probes[id];
      const ids=Object.keys(probes);while(ids.length>=10)delete probes[ids.shift()];
      probes[token]={url,currency,quotes,at:now()};await api.storage.session.set({alertProbes:probes});
    });
    return {token,quotes};
  }
  async function enable(id,token,key,mode) {
    return locked(async()=>{
      const item=await itemFor(id),data=await api.storage.session.get('alertProbes'),p=data.alertProbes?.[token];
      if(!p || now()-p.at>10*60000 || p.url!==item.url)throw new Error('stale');
      const quote=p.quotes.find(q=>q.key===key);if(!quote || !['saved','fresh'].includes(mode))throw new Error('stale');
      const shop=shopFor(item.url);if(!shop || !await api.permissions.contains({origins:[shop.origin]}))throw new Error('permission');
      const previous=await get('tracking:'+id);
      if(previous?.enabled)return previous;
      const track=createTracking(item,quote,mode,p.at,previous);
      await put(track);return track;
    });
  }
  async function disable(id) {
    return locked(async()=>{
      const t=await get('tracking:'+id);if(!t)return;
      const next={...t,enabled:false,status:'disabled',candidate:null,generation:crypto.randomUUID(),events:t.events.map(e=>e.delivery==='pending'?{...e,delivery:'cancelled'}:e)};
      await put(next);return next;
    });
  }
  async function check(id,force=false) {
    const snapshot=await locked(async()=>{
      const item=await itemFor(id),t=await get('tracking:'+id);if(!t?.enabled)return null;
      if(t.url!==item.url || t.currency!==item.currency){await put(failTracking(t,'changed',now()));return null;}
      if(force && t.lastAttemptAt && now()-t.lastAttemptAt<5*60000)throw new Error('cooldown');
      if(!force && t.nextCheckAt>now())return null;
      // Persist the lease before network I/O so a terminated worker can resume later.
      await put({...t,lastAttemptAt:now(),nextCheckAt:now()+5*60000});return t;
    });
    if(!snapshot)return;
    let quote,error;
    try{const quotes=await read(snapshot.url);quote=quotes.find(q=>q.key===snapshot.key);if(!quote)throw new Error('changed');}catch(e){error=e.message;}
    await locked(async()=>{
      const t=await get('tracking:'+id),item=await get('item:'+id);
      if(!t?.enabled || t.generation!==snapshot.generation || !item || item.purchased)return;
      if(t.url!==item.url || t.currency!==item.currency){await put(failTracking(t,'changed',now()));return;}
      if(error){await put(failTracking(t,error,now()));return;}
      try{await put(applyQuote(t,quote,now()));}catch(e){await put(failTracking(t,e.message,now()));}
    });
  }
  async function reconcile() {
    for(const track of await list()) {
      const item=await get('item:'+track.id);
      if(!item){await locked(()=>api.storage.local.remove('tracking:'+track.id));continue;}
      if(track.enabled && item.purchased){await disable(track.id);continue;}
      const shop=shopFor(item.url);
      if(track.enabled && (!shop || !await api.permissions.contains({origins:[shop.origin]}))) {
        await locked(async()=>{const latest=await get('tracking:'+track.id);if(latest?.enabled && latest.status!=='permission')await put(failTracking(latest,shop?'permission':'unsupported',now()));});
      }
    }
  }
  async function deliver() {
    if(!await api.permissions.contains({permissions:['notifications']}) || !api.notifications)return;
    if(await api.notifications.getPermissionLevel()!=='granted')return;
    for(const snapshot of await list()) {
      for(const event of snapshot.events.filter(e=>e.delivery==='pending' && (e.nextDeliveryAt||0)<=now())) {
        await locked(async()=>{
          const track=await get('tracking:'+snapshot.id),item=await get('item:'+snapshot.id);
          const current=track?.events.find(e=>e.id===event.id);
          if(!track?.enabled || !item || item.purchased || track.url!==item.url || !current || current.delivery!=='pending')return;
          const format=n=>new Intl.NumberFormat('es-ES',{style:'currency',currency:event.currency}).format(n);
          try {
            await api.notifications.create('wannit:'+item.id+':'+event.id,{type:'basic',iconUrl:api.runtime.getURL('icons/wannit-128.png'),title:'Ha bajado: '+item.title.slice(0,90),message:`Ahora ${format(event.price)} · Al activar: ${format(event.referencePrice)}. Ahorras ${format(event.referencePrice-event.price)}.`});
            current.delivery='sent';current.deliveredAt=now();
          }catch{current.attempts=(current.attempts||0)+1;current.nextDeliveryAt=now()+Math.min(24*60,30*2**Math.min(current.attempts,5))*60000;}
          await put(track);
        });
      }
    }
  }
  async function tick(){
    if(ticking)return;ticking=true;
    try{await reconcile();const due=(await list()).filter(t=>t.enabled && t.status!=='permission' && t.nextCheckAt<=now()).sort((a,b)=>a.nextCheckAt-b.nextCheckAt);if(due[0])await check(due[0].id);await deliver();}finally{ticking=false;}
  }
  async function markRead(id,eventId){await locked(async()=>{const t=await get('tracking:'+id);if(t){for(const e of t.events)if(!eventId || e.id===eventId){e.read=true;if(e.delivery==='pending')e.delivery='cancelled';}await put(t);}});}
  async function resume(id){await locked(async()=>{const t=await get('tracking:'+id);if(t?.enabled){const shop=shopFor(t.url);if(!shop || !await api.permissions.contains({origins:[shop.origin]}))throw new Error('permission');await put({...t,status:'pending',nextCheckAt:now()});}});}
  async function message(m){
    switch(m.action){case 'probe':return probe(m.url,m.currency);case 'enable':{const result=await enable(m.id,m.token,m.key,m.mode);return result;}case 'disable':return disable(m.id);case 'check':await check(m.id,true);await deliver();return;case 'read':return markRead(m.id,m.eventId);case 'resume':return resume(m.id);default:throw new Error('unreadable');}
  }
  return {probe,enable,disable,check,tick,reconcile,deliver,markRead,message,list};
}
