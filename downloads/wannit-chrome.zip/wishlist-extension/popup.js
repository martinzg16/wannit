import {mountAlertControl,readTracking,alertCall} from './alert-ui.js';
import { readLists, listLabel } from './lists.js';
import { listPicker } from './list-picker.js';
import { enter } from './motion.js';
import { api, readItems, saveItem, safeUrl, money } from './store.js';
import { extractProduct } from './extract.js';
import { inferCategory, captureCategories, mountCategoryFields, setCategoryFields, readCategoryFields } from './catalog.js';
import { detectDiscount } from './discount.js';
let discountDetection = null;
let capturedUrl = '';
const form = document.querySelector('form');
const status = document.querySelector('#status');
let createdListName = '';
let alertPlan=null, existingForAlert=null, savedItemId=null;
const draftId=crypto.randomUUID();
const draftItem=()=>({id:existingForAlert?.id||draftId,title:form.elements.title.value,url:form.elements.url.value,price:form.elements.price.value===''?null:Number(form.elements.price.value),currency:form.elements.currency.value.toUpperCase(),createdAt:existingForAlert?.createdAt||new Date().toISOString(),updatedAt:existingForAlert?.updatedAt,purchased:existingForAlert?.purchased||false});
async function refreshPopupAlert(){
 const t=await readTracking();const item=existingForAlert||draftItem();
 mountAlertControl(document.querySelector('#popup-alert-control'),item,{track:t[item.id],getItem:draftItem,planned:Boolean(alertPlan),onPlan:existingForAlert?null:async plan=>{alertPlan=plan;await refreshPopupAlert();}});
}
async function finishAlert(id){
 savedItemId=id;
 const note=document.querySelector('#saved-alert-note');
 if(alertPlan){try{await alertCall('enable',{id,...alertPlan});note.textContent='Alerta activada. Te avisaremos si baja.';}catch(e){note.textContent='Producto guardado. La alerta no se ha activado: '+e.message;}}
 const item=(await readItems()).find(i=>i.id===id),t=await readTracking();
 if(item)mountAlertControl(document.querySelector('#saved-alert-control'),item,{track:t[id]});
}
api.storage.onChanged.addListener((changes,area)=>{
 if(area==='local' && Object.keys(changes).some(k=>k.startsWith('tracking:'))){
  if(savedItemId)finishAlertRefresh().catch(()=>{});else refreshPopupAlert().catch(()=>{});
 }
});
async function finishAlertRefresh(){const item=(await readItems()).find(i=>i.id===savedItemId),t=await readTracking();if(item)mountAlertControl(document.querySelector('#saved-alert-control'),item,{track:t[item.id]});}

async function updateDestination() { document.querySelector('#destination-label').textContent = listLabel(await readLists(), form.elements.listId.value); }
document.querySelector('#choose-list').onclick = () => listPicker({current:form.elements.listId.value || null,createText:'Crear y guardar',onConfirm:async(id,created)=>{
 form.elements.listId.value=id||''; createdListName=created?.name||'';await updateDestination();
 if(created)setTimeout(()=>form.requestSubmit(),0);
}});

form.inert = true;
form.setAttribute('aria-busy', 'true');
function preview() {
 const f = form.elements;
 document.querySelector('#product-preview').hidden = !f.title.value;
 document.querySelector('#preview-title').textContent = f.title.value;
 document.querySelector('#preview-price').textContent = money(f.price.value === '' ? null : Number(f.price.value), f.currency.value || 'EUR');
 const original = document.querySelector('#preview-original');
 original.hidden = !(f.price.value !== '' && Number(f.originalPrice.value) > Number(f.price.value));
 original.textContent = original.hidden ? '' : money(Number(f.originalPrice.value), f.currency.value || 'EUR');
 try { document.querySelector('#preview-store').textContent = new URL(f.url.value).hostname.replace(/^www\./,''); } catch {}
 const img = document.querySelector('#preview-image');
 const src = safeUrl(f.image.value);
 img.hidden = !src || img.dataset.failedSrc === src;
 document.querySelector('#preview-placeholder').hidden = !img.hidden;
 if (src && img.getAttribute('src') !== src) { img.src = src; img.referrerPolicy = 'no-referrer'; }
 img.onerror = () => { img.dataset.failedSrc = src; img.hidden = true; document.querySelector('#preview-placeholder').hidden = false; };
}
function showSaved() {
 form.hidden = true; document.querySelector('#product-preview').hidden = true; status.textContent = '';
 document.querySelector('#saved-state').hidden = false;
 document.querySelector('#view-saved').focus();
 document.querySelector('#saved-categories').textContent = 'Producto guardado en ' + document.querySelector('#destination-label').textContent;
 document.querySelector('#view-saved').textContent = form.elements.listId.value ? 'Abrir lista ↗' : 'Ver mis guardados ↗';
 document.querySelector('#saved-state h2').textContent = createdListName ? 'LISTA CREADA' : 'GUARDADO';
 enter(document.querySelector('.success-mark'),'success');
}
form.addEventListener('input', preview);
form.addEventListener('invalid', event => { const details = event.target.closest('details'); if (details) details.open = true; }, true);
document.querySelector('#view-saved').onclick = () => form.elements.listId.value ? api.tabs.create({url:api.runtime.getURL('wishlist.html')+'?list='+encodeURIComponent(form.elements.listId.value)}) : api.runtime.openOptionsPage();
mountCategoryFields(form);
const originalField = document.querySelector('#original-price-field');
const syncOriginalField = () => {
  originalField.hidden = !(form.elements.price.value !== '' && Number(form.elements.originalPrice.value) > Number(form.elements.price.value));
};
form.elements.price.addEventListener('input', syncOriginalField);
syncOriginalField();
document.querySelector('#open-list').onclick = () => api.runtime.openOptionsPage();
try {
  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  if (tab?.url) form.elements.url.value = safeUrl(tab.url);
  const results = await api.scripting.executeScript({ target: { tabId: tab.id }, func: extractProduct });
  const data = results[0].result;
  for (const key of ['title', 'price', 'currency', 'url', 'image']) form.elements[key].value = data[key] ?? '';
  setCategoryFields(form, [inferCategory(data.title, data.categoryHint)]);
  capturedUrl = safeUrl(data.url);
  try {
    const results = await api.scripting.executeScript({ target: { tabId: tab.id }, func: detectDiscount, args: [data.price, data.currency] });
    discountDetection = results[0].result;
    if (safeUrl(discountDetection.sourceUrl) !== capturedUrl) discountDetection = null;
    form.elements.originalPrice.value = discountDetection?.originalPrice ?? '';
    syncOriginalField();
  } catch { /* Manual correction remains available. */ }
  const saved = (await readItems()).find(item => item.url === capturedUrl);
  existingForAlert=saved||null;
  if (saved) {
    setCategoryFields(form, captureCategories(data.title, data.categoryHint, saved));
    form.elements.listId.value = saved.listId || '';
    await updateDestination();
    for (const key of ['title','notes']) form.elements[key].value = saved[key] ?? '';
    document.querySelector('#save').textContent = 'Actualizar guardado';
  }
  status.textContent = saved ? 'Ya lo tienes guardado. Revisa los datos antes de actualizarlo.' : data.multiple ? 'Hay varios productos. Revisa que los datos correspondan al que quieres.' : 'Revisa el precio y la variante antes de guardar.';
} catch {
  status.textContent = form.elements.url.value ? 'No se pudo leer el producto. Completa su nombre y precio.' : 'Abre una ficha de producto en una tienda para guardarla.';
  document.querySelector('#save').disabled = !form.elements.url.value;
}
preview();
await refreshPopupAlert();
form.inert = false;
form.removeAttribute('aria-busy');
const saveButton = document.querySelector('#save');
saveButton.disabled = !safeUrl(form.elements.url.value);
if (saveButton.textContent === 'Leyendo producto…') saveButton.textContent = 'Guardar';
if (!safeUrl(form.elements.url.value)) form.hidden = true;
if (!form.elements.title.value || !form.elements.price.value) {
 document.querySelector('#product-edit').open = true;
 if (safeUrl(form.elements.url.value)) status.textContent = 'Faltan datos del producto. Completa o revisa los campos antes de guardar.';
}
form.onsubmit = async event => {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(form));
  const url = safeUrl(values.url);
  if (!url) { status.textContent = 'Abre la ficha del producto en una tienda y vuelve a pulsar la extensión.'; return; }
  if (!values.title.trim()) { status.textContent = 'Escribe un nombre para el producto.'; return; }
  const price = values.price === '' ? null : Number(values.price);
  const originalPrice = originalField.hidden || values.originalPrice === '' ? null : Number(values.originalPrice);
  if (originalPrice !== null && (price === null || originalPrice < price)) { status.textContent = 'El precio original debe ser igual o mayor que el actual.'; return; }
  const button = document.querySelector('#save');
  button.disabled = true;
  try {
    const existing = (await readItems()).find(item => item.url === url);
    const catalog = { listId: values.listId || null, price, originalPrice, currency: values.currency.toUpperCase(), categories: readCategoryFields(form), category: readCategoryFields(form)[0] || 'Sin categorizar', discountCheckedAt: originalPrice !== null ? new Date().toISOString() : (url === capturedUrl ? discountDetection?.checkedAt ?? null : null) };
    if (existing) {
      await saveItem({ ...existing, ...catalog, image: safeUrl(values.image) || existing.image || '', title: values.title.trim(), notes: values.notes, updatedAt: new Date().toISOString() });
      status.textContent = 'Precio, categoría y detecciones actualizados. Tus notas se conservan.';
      button.textContent = 'Guardado ✓';
      await finishAlert(existing.id);
      showSaved();
      return;
    }
    await saveItem({ ...values, ...catalog, title: values.title.trim(), url, image: safeUrl(values.image), currency: values.currency.toUpperCase(), price: values.price === '' ? null : Number(values.price), id: draftId, createdAt: new Date().toISOString(), purchased: false });
    await finishAlert(draftId);
    status.textContent = '¡Guardado! Ya está en tu wishlist.';
    button.textContent = 'Guardado ✓';
      showSaved();
    return;
  } catch { status.textContent = 'No se pudo guardar. Inténtalo de nuevo.'; }
  finally { if (button.textContent !== 'Guardado ✓') button.disabled = false; }
};
