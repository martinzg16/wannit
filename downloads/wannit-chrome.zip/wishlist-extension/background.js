import {createAlertService} from './alert-service.js';
import {errorText} from './alert-core.js';
const service=createAlertService(chrome);
const report=error=>console.warn('Wannit: seguimiento pendiente de reintento.',error?.message);
async function initialize(){if(!await chrome.alarms.get('wannit-prices'))await chrome.alarms.create('wannit-prices',{periodInMinutes:1});await service.tick();}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message?.target!=='wannit-alerts' || sender.id!==chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('')))return;
  service.message(message).then(value=>respond({ok:true,value})).catch(e=>respond({ok:false,error:e.message,message:errorText(e.message)}));
  return true;
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='wannit-prices')service.tick().catch(report);});
chrome.runtime.onInstalled.addListener(()=>initialize().catch(report));
chrome.runtime.onStartup.addListener(()=>initialize().catch(report));
chrome.permissions.onRemoved.addListener(()=>service.reconcile().catch(report));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local' && Object.keys(changes).some(k=>k.startsWith('item:')))service.reconcile().catch(report);});
let notificationListenerAdded=false;
function registerNotifications(){
 if(notificationListenerAdded || !chrome.notifications?.onClicked)return;
 notificationListenerAdded=true;
 chrome.notifications.onClicked.addListener(async notificationId=>{
  if(!notificationId.startsWith('wannit:'))return;
  const [,id,...parts]=notificationId.split(':');const eventId=parts.join(':');
  const data=await chrome.storage.local.get(['item:'+id,'tracking:'+id]),item=data['item:'+id],track=data['tracking:'+id];
  if(!item || !track?.events.some(e=>e.id===eventId))return;
  await service.markRead(id,eventId);
  const url=new URL(item.url);if(url.protocol==='https:')await chrome.tabs.create({url:url.href});
});
}
registerNotifications();
chrome.permissions.onAdded.addListener(()=>{registerNotifications();service.tick().catch(report);});
initialize().catch(report);
