let nextId = 0;
// Inline disclosure, not a menu: native buttons, normal Tab order, Escape to close.
export function createChipPicker(host, { options, label, multiple = false, onChange }) {
  const id = `chip-options-${++nextId}`;
  let selected = [], detected = [], expanded = false, animation;
  const row = document.createElement('div'); row.className = 'chip-row';
  const chips = document.createElement('div'); chips.className = 'chip-values';
  const toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'chip chip-add';
  toggle.textContent = '+'; toggle.setAttribute('aria-label', `Mostrar ${label.toLowerCase()} disponibles`); toggle.setAttribute('aria-controls',id); toggle.setAttribute('aria-expanded','false');
  const panel = document.createElement('div'); panel.id = id; panel.className = 'chip-options'; panel.hidden = true;
  const caption = document.createElement('p'); caption.className = 'chip-caption'; caption.textContent = label;
  const choices = document.createElement('div'); choices.className = 'chip-values';
  panel.append(caption,choices); row.append(chips,toggle); host.replaceChildren(row,panel); host.classList.add('chip-picker');
  function setExpanded(open, instant = false) {
    expanded = open; toggle.setAttribute('aria-expanded',String(open)); toggle.textContent = open ? '−' : '+';
    toggle.setAttribute('aria-label',`${open ? 'Ocultar' : 'Mostrar'} ${label.toLowerCase()} disponibles`);
    if (!open && panel.contains(document.activeElement)) toggle.focus();
    const style = panel.hidden ? null : getComputedStyle(panel);
    const from = {opacity:style?.opacity ?? '0',transform:style?.transform === 'none' ? 'scale(1)' : style?.transform ?? 'scale(.97)'};
    animation?.cancel(); panel.hidden = false; panel.inert = !open;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (instant || reduced) { panel.hidden = !open; return; }
    const tokens = getComputedStyle(document.documentElement);
    const duration = parseFloat(tokens.getPropertyValue('--duration-disclosure')) || 180;
    const easing = tokens.getPropertyValue('--ease-out').trim() || 'cubic-bezier(0.23, 1, 0.32, 1)';
    animation = panel.animate([from,{opacity:open?'1':'0',transform:open?'scale(1)':'scale(.97)'}],{duration,easing,fill:'both'});
    const active = animation;
    active.finished.then(()=>{if(animation===active){panel.hidden=!expanded;active.cancel();animation=null;}}).catch(()=>{});
  }
  toggle.onclick = event => setExpanded(!expanded,event.detail === 0);
  host.addEventListener('keydown',event=>{if(event.key==='Escape' && expanded){event.preventDefault();setExpanded(false,true);toggle.focus();}});
  function choose(value) {
    selected = multiple ? selected.includes(value) ? selected.filter(x=>x!==value) : [...selected,value] : value ? [value] : [];
    draw(); onChange?.([...selected]);
  }
  function button(value, text, remove = false) {
    const b=document.createElement('button'); b.type='button'; b.className='chip';
    b.textContent=text; b.setAttribute('aria-pressed',String(value ? selected.includes(value) : selected.length===0));
    if(remove){b.textContent += ' ×'; b.setAttribute('aria-label',`Quitar ${value}`);}
    b.onclick=()=>{choose(value); if(!b.isConnected) toggle.focus();}; return b;
  }
  function draw() {
    chips.replaceChildren(); choices.replaceChildren();
    if(!multiple) chips.append(button('','Todas'));
    const visible=multiple?selected:[...new Set([...detected,...selected])];
    for(const value of options.filter(value=>visible.includes(value))) chips.append(button(value,value,multiple));
    if(multiple && !selected.length){const empty=document.createElement('span');empty.className='chip-empty';empty.textContent='Sin categorizar';chips.append(empty);}
    for(const value of options) choices.append(button(value,value));
  }
  return {
    set(values, available = detected) { selected=values.filter(x=>options.includes(x)); detected=available.filter(x=>options.includes(x)); draw(); },
    get() { return [...selected]; }
  };
}
