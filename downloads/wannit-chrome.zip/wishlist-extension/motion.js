// Existing native controls own focus and state. Motion only communicates their changes.
let keyboard=false;
document.addEventListener('keydown',()=>{keyboard=true;},true);
document.addEventListener('pointerdown',()=>{keyboard=false;},true);
export function enter(node,kind='panel') {
 if(!node || keyboard || matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 node.getAnimations().forEach(animation=>animation.cancel());
 const easing=getComputedStyle(document.documentElement).getPropertyValue('--ease-out').trim() || 'cubic-bezier(.23,1,.32,1)';
 if(kind==='success'){node.animate([{opacity:0,transform:'scale(.6)'},{opacity:1,transform:'scale(1.08)',offset:.6},{opacity:1,transform:'scale(1)'}],{duration:350,easing});return;}
 node.animate([{opacity:0,transform:kind==='success'?'scale(.95)':kind==='view'?'translateY(6px)':'translateY(6px) scale(.98)'},{opacity:1,transform:'none'}],{duration:kind==='success'?250:200,easing});
}
export function openDialog(dialog){dialog.showModal();enter(dialog);}
