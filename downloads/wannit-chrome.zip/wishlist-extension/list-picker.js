import { readLists, createList, renameList } from './lists.js';
import { readItems, safeUrl, money } from './store.js';
import { openDialog, enter } from './motion.js';
const el=(tag,text,className)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(className)n.className=className;return n;};
let nextId=0;
// One native dialog shared by popup and wishlist. Escape, focus trapping and return are native.
export function listPicker({title='Guardar en…',current=null,createOnly=false,renaming=null,confirmText='Elegir lista',createText='Crear y elegir',onConfirm}) {
 const dialog=el('dialog',null,'list-dialog'),form=el('form'),head=el('div',null,'list-dialog-head');
 const heading=el('h2',renaming?'RENOMBRAR LISTA':createOnly?'NUEVA LISTA':title);heading.id='list-picker-'+(++nextId);dialog.setAttribute('aria-labelledby',heading.id);
 const close=el('button','×','secondary icon-button');close.type='button';close.setAttribute('aria-label','Cerrar selector de listas');close.onclick=()=>dialog.close();head.append(heading,close);
 const search=el('input');search.type='search';search.placeholder='Buscar una lista';search.setAttribute('aria-label','Buscar una lista');
 const choices=el('div',null,'list-options');choices.setAttribute('role','group');choices.setAttribute('aria-label','Listas disponibles');
 const start=el('button','＋ Crear una lista nueva','list-create-trigger');start.type='button';
 const createArea=el('div',null,'list-create-fields');const nameLabel=el('label','Nombre de la lista'),name=el('input');name.maxLength=80;name.placeholder='Piso nuevo, regalos, algún día…';nameLabel.append(name);
 const privacy=el('p','Solo tú · Guardada en este navegador','list-privacy');
 const cover=el('div',null,'list-cover-hint');const illustration=el('img');illustration.src='illustrations/chair.svg';illustration.alt='';cover.append(illustration,el('p','La portada se forma con tus productos. Mientras tanto, un pequeño guiño de wannit.'));
 const cancelCreate=el('button','Volver a mis listas','text-button');cancelCreate.type='button';
 const productsArea=el('section',null,'new-list-products');productsArea.setAttribute('aria-label','Añadir productos guardados');
 const productsTitle=el('h3','Añadir productos guardados');
 const productsHelp=el('p','Opcional. Los seleccionados se moverán a esta lista.','hint');
 const productSearch=el('input');productSearch.type='search';productSearch.placeholder='Buscar entre tus guardados';productSearch.setAttribute('aria-label','Buscar productos guardados');
 const productCount=el('p','0 seleccionados','hint');productCount.setAttribute('role','status');
 const productOptions=el('div',null,'new-list-product-options');
 productsArea.append(productsTitle,productsHelp,productSearch,productCount,productOptions);
 productsArea.hidden=!!renaming;
 createArea.append(nameLabel,privacy,cover,productsArea,cancelCreate);
 const error=el('p',null,'list-error');error.setAttribute('role','alert');const footer=el('div',null,'list-dialog-footer'),cancel=el('button','Cancelar','secondary'),submit=el('button',confirmText);cancel.type='button';cancel.onclick=()=>dialog.close();submit.type='submit';footer.append(cancel,submit);
 form.append(head,search,choices,start,createArea,error,footer);dialog.append(form);document.body.append(dialog);
 let products=[];const picked=new Set();
 let lists=[],selected=current,creating=createOnly||!!renaming,busy=false,committed=null;
 function mode(){heading.textContent=renaming?'RENOMBRAR LISTA':creating?'NUEVA LISTA':title;createArea.hidden=!creating;search.hidden=choices.hidden=start.hidden=creating;cancelCreate.hidden=createOnly||!!renaming;name.required=creating;submit.textContent=renaming?'Guardar nombre':creating?(createOnly?'Crear lista':createText):confirmText;error.textContent='';}
 function draw(){choices.replaceChildren();const query=search.value.toLocaleLowerCase('es');const options=[{id:null,name:'Sin lista',detail:'Se queda en Todos los guardados'},...lists];let found=0;
  for(const list of options){if(!list.name.toLocaleLowerCase('es').includes(query))continue;found++;const label=el('label',null,'list-option'),radio=el('input');radio.type='radio';radio.name='destination';radio.value=list.id||'';radio.checked=selected===list.id;radio.onchange=()=>{selected=list.id;};label.append(radio,el('span',list.name),el('small',list.detail||'Lista personal'));choices.append(label);}
  if(!found)choices.append(el('p','No hay listas con ese nombre. Puedes crear una nueva.','hint'));
 }
 function drawProducts(){
  productOptions.replaceChildren();const query=productSearch.value.trim().toLocaleLowerCase('es');
  const visible=products.filter(item=>(item.title||'').toLocaleLowerCase('es').includes(query));
  productCount.textContent=`${picked.size} ${picked.size===1?'seleccionado':'seleccionados'}`;
  for(const item of visible){
   const row=el('label',null,'new-list-product'),check=el('input');check.type='checkbox';check.checked=picked.has(item.id);check.setAttribute('aria-label','Añadir '+item.title);
   check.onchange=()=>{if(check.checked)picked.add(item.id);else picked.delete(item.id);productCount.textContent=`${picked.size} ${picked.size===1?'seleccionado':'seleccionados'}`;};
   const photo=el('span',null,'new-list-product-photo');const src=safeUrl(item.image);if(src){const img=el('img');img.src=src;img.alt='';img.referrerPolicy='no-referrer';img.onerror=()=>img.remove();photo.append(img);}
   const info=el('span',null,'new-list-product-info');info.append(el('span',item.title),el('small',money(item.price,item.currency)+' · '+(lists.find(list=>list.id===item.listId)?.name||'Sin lista')));
   row.append(check,photo,info);productOptions.append(row);
  }
  if(!visible.length)productOptions.append(el('p',products.length?'No hay productos con ese nombre.':'Aún no tienes productos guardados. Puedes crear la lista vacía.','hint'));
 }
 productSearch.oninput=drawProducts;
 if(!renaming){productOptions.append(el('p','Cargando tus guardados…','hint'));Promise.all([readItems(),readLists()]).then(([saved,collections])=>{if(!dialog.isConnected)return;products=saved;lists=collections;cover.hidden=products.length>0;productSearch.hidden=products.length===0;drawProducts();}).catch(()=>{productOptions.replaceChildren(el('p','No se pudieron cargar tus guardados. Puedes crear la lista vacía y añadirlos después.','hint'));});}
 start.onclick=()=>{creating=true;mode();enter(createArea);name.focus();};cancelCreate.onclick=()=>{creating=false;mode();search.focus();};search.oninput=draw;
 form.onsubmit=async event=>{event.preventDefault();if(busy)return;busy=true;submit.disabled=true;cancel.disabled=true;close.disabled=true;
  try{let created=committed;if(creating&&!created){created=renaming?await renameList(renaming.id,name.value):await createList(name.value,[...picked]);committed=created;}await onConfirm(created?.id??selected,created);dialog.close();}
  catch(e){error.textContent=e.message||'No se pudo guardar la lista.';}
  finally{busy=false;submit.disabled=false;cancel.disabled=false;close.disabled=false;}
 };
 dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});dialog.addEventListener('close',()=>dialog.remove());
 mode();if(renaming)name.value=renaming.name;openDialog(dialog);
 if(creating)name.focus();else{submit.disabled=true;readLists().then(data=>{if(!dialog.isConnected)return;lists=data;draw();submit.disabled=false;}).catch(()=>{error.textContent='No se pudieron cargar las listas. Cierra y vuelve a intentarlo.';});}
 return dialog;
}
