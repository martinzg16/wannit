import { readLists, createList, renameList } from './lists.js';
import { openDialog, enter } from './motion.js';
const el=(tag,text,className)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(className)n.className=className;return n;};
let nextId=0;
// One native dialog shared by popup and wishlist. Escape, focus trapping and return are native.
export function listPicker({title='Guardar en…',current=null,createOnly=false,renaming=null,confirmText='Elegir lista',createText='Crear y elegir',onConfirm}) {
 const dialog=el('dialog',null,'list-dialog'),form=el('form'),head=el('div',null,'list-dialog-head');
 const heading=el('h2',renaming?'RENOMBRAR LISTA':createOnly?'NUEVA LISTA':title);heading.id='list-picker-'+(++nextId);dialog.setAttribute('aria-labelledby',heading.id);
 const close=el('button','×','secondary icon-button');close.type='button';close.setAttribute('aria-label','Cerrar selector de listas');close.onclick=()=>dialog.close();head.append(heading,close);
 const search=el('input');search.type='search';search.placeholder='Buscar una lista';search.setAttribute('aria-label','Buscar una lista');
 const choices=el('div',null,'list-options');choices.setAttribute('role','group');choices.setAttribute('aria-label','Listas disponibles');
 const start=el('button','＋ Crear una lista nueva','list-create-trigger');start.type='button';
 const createArea=el('div',null,'list-create-fields');const nameLabel=el('label','Nombre de la lista'),name=el('input');name.maxLength=80;name.placeholder='Piso nuevo, regalos, algún día…';nameLabel.append(name);
 const privacy=el('p','Solo tú · Guardada en este navegador','list-privacy');
 const cover=el('div',null,'list-cover-hint');const illustration=el('img');illustration.src='illustrations/chair.svg';illustration.alt='';cover.append(illustration,el('p','La portada se forma con tus productos. Mientras tanto, un pequeño guiño de wannit.'));
 const cancelCreate=el('button','Volver a mis listas','text-button');cancelCreate.type='button';
 createArea.append(nameLabel,privacy,cover,cancelCreate);
 const error=el('p',null,'list-error');error.setAttribute('role','alert');const footer=el('div',null,'list-dialog-footer'),cancel=el('button','Cancelar','secondary'),submit=el('button',confirmText);cancel.type='button';cancel.onclick=()=>dialog.close();submit.type='submit';footer.append(cancel,submit);
 form.append(head,search,choices,start,createArea,error,footer);dialog.append(form);document.body.append(dialog);
 let lists=[],selected=current,creating=createOnly||!!renaming,busy=false,committed=null;
 function mode(){heading.textContent=renaming?'RENOMBRAR LISTA':creating?'NUEVA LISTA':title;createArea.hidden=!creating;search.hidden=choices.hidden=start.hidden=creating;cancelCreate.hidden=createOnly||!!renaming;name.required=creating;submit.textContent=renaming?'Guardar nombre':creating?(createOnly?'Crear lista':createText):confirmText;error.textContent='';}
 function draw(){choices.replaceChildren();const query=search.value.toLocaleLowerCase('es');const options=[{id:null,name:'Sin lista',detail:'Se queda en Todos los guardados'},...lists];let found=0;
  for(const list of options){if(!list.name.toLocaleLowerCase('es').includes(query))continue;found++;const label=el('label',null,'list-option'),radio=el('input');radio.type='radio';radio.name='destination';radio.value=list.id||'';radio.checked=selected===list.id;radio.onchange=()=>{selected=list.id;};label.append(radio,el('span',list.name),el('small',list.detail||'Lista personal'));choices.append(label);}
  if(!found)choices.append(el('p','No hay listas con ese nombre. Puedes crear una nueva.','hint'));
 }
 start.onclick=()=>{creating=true;mode();enter(createArea);name.focus();};cancelCreate.onclick=()=>{creating=false;mode();search.focus();};search.oninput=draw;
 form.onsubmit=async event=>{event.preventDefault();if(busy)return;busy=true;submit.disabled=true;cancel.disabled=true;close.disabled=true;
  try{let created=committed;if(creating&&!created){created=renaming?await renameList(renaming.id,name.value):await createList(name.value);committed=created;}await onConfirm(created?.id??selected,created);dialog.close();}
  catch(e){error.textContent=e.message||'No se pudo guardar la lista.';}
  finally{busy=false;submit.disabled=false;cancel.disabled=false;close.disabled=false;}
 };
 dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});dialog.addEventListener('close',()=>dialog.remove());
 mode();if(renaming)name.value=renaming.name;openDialog(dialog);
 if(creating)name.focus();else{submit.disabled=true;readLists().then(data=>{if(!dialog.isConnected)return;lists=data;draw();submit.disabled=false;}).catch(()=>{error.textContent='No se pudieron cargar las listas. Cierra y vuelve a intentarlo.';});}
 return dialog;
}
