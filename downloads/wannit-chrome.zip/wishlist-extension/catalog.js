import { createChipPicker } from './chip-picker.js';
const categoryPickers = new WeakMap();
export const categories = ['Sin categorizar', 'Ropa', 'Calzado', 'Accesorios', 'Tecnología', 'Hogar', 'Deporte', 'Salud', 'Belleza', 'Libros y ocio', 'Otros'];
export function inferCategory(title = '', hint = '') {
  const text = `${hint} ${title}`.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const rules = [
    ['Calzado', /\b(zapatillas?|zapatos?|botas?|sandalias?|sneakers?|shoes?|footwear)\b/],
    ['Ropa', /\b(pantalon(?:es)?|camisetas?|camisas?|vestidos?|chaquetas?|cazadoras?|sobrecamisas?|abrigos?|chalecos?|americanas?|blazers?|sudaderas?|jerseys?|jerseis|sueter(?:es)?|polos?|bermudas?|mallas|leggings?|calcetines?|shorts?|clothing|apparel|shirts?|jackets?|coats?|overshirts?|knitwear|sweaters?|hoodies?|trousers?|pants)\b/],
    ['Accesorios', /\b(bolsos?|mochilas?|gafas|cinturon(?:es)?|joyas?|collares?|pendientes|wallet|handbag|backpack)\b/],
    ['Tecnología', /\b(portatil(?:es)?|ordenador(?:es)?|auriculares|movil(?:es)?|smartphone|tablet|monitor|teclado|smartwatch|laptop|headphones|electronics)\b/],
    ['Hogar', /\b(sofa|sillas?|mesas?|lamparas?|estanterias?|alfombras?|cojines?|vajilla|muebles|furniture|chair|lighting)\b/],
    ['Deporte', /\b(bicicleta|raqueta|mancuernas?|pesas|balon|esterilla|fitness|cycling|yoga|sports equipment)\b/],
    ['Salud', /\b(tensiometro|termometro|pulsioximetro|bascula|salud|health)\b/],
    ['Belleza', /\b(perfume|crema|maquillaje|serum|champu|cosmetica|beauty|skincare)\b/],
    ['Libros y ocio', /\b(libro|novela|comic|videojuego|puzzle|juguete|book|toys?|board game)\b/]
  ];
  return rules.find(([, expression]) => expression.test(text))?.[0] || 'Sin categorizar';
}
export function categoriesOf(item) {
  if (Array.isArray(item.categories)) {
    const valid = [...new Set(item.categories.filter(value => categories.includes(value) && value !== 'Sin categorizar'))];
    return valid.length ? valid : ['Sin categorizar'];
  }
  return [categories.includes(item.category) ? item.category : inferCategory(item.title)];
}
// Keep selected categories; an uncategorized saved item may receive a new suggestion.
export function captureCategories(title, hint, saved) {
  const selected = saved ? categoriesOf(saved).filter(value => value !== 'Sin categorizar') : [];
  return selected.length ? selected : [inferCategory(title, hint)];
}
export function categoryOf(item) { return categoriesOf(item)[0]; }
export function mountCategoryFields(form) {
  const fieldset = form.querySelector('[data-categories]');
  const host=document.createElement('div'); fieldset.append(host);
  const picker=createChipPicker(host,{options:categories.filter(name=>name!=='Sin categorizar'),label:'Categorías',multiple:true});
  categoryPickers.set(form,picker); picker.set([]);
}
export function setCategoryFields(form, values) { categoryPickers.get(form).set(values); }
export function readCategoryFields(form) { return categoryPickers.get(form).get(); }
export function discountOf(item) {
  if (Number.isFinite(item.price) && Number.isFinite(item.originalPrice) && item.price >= 0 && item.originalPrice > item.price) {
    return { status: 'discounted', percent: Math.round((1 - item.price / item.originalPrice) * 1000) / 10 };
  }
  return { status: Number.isFinite(item.price) && item.discountCheckedAt ? 'not_detected' : 'unchecked', percent: null };
}
export function matchesCatalog(item, category, discount) {
  return (!category || categoriesOf(item).includes(category)) && (!discount || discountOf(item).status === discount);
}
export function fillCategories(select, includeAll = false) {
  select.replaceChildren();
  for (const name of [...(includeAll ? ['Todas las categorías'] : []), ...categories]) {
    const option = document.createElement('option'); option.value = name === 'Todas las categorías' ? '' : name; option.textContent = name; select.append(option);
  }
}
