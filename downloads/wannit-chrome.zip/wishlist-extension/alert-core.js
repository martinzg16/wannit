import { minor } from './alert-readers.js';
export const DAY=24*60*60*1000;
export const ERROR_TEXT={unsupported:'Esta tienda o este enlace aún no admite alertas. Disponibles: Nike España y Everyday Better Club.',permission:'Nos falta permiso para consultar esta tienda.',currency:'La tienda devuelve otra moneda. No compararemos precios de mercados distintos.',variant:'No podemos identificar un precio común. Abre y guarda el enlace de la variante exacta.',ambiguous:'La tienda devuelve precios contradictorios. Conservamos la última lectura válida.',unreadable:'No hemos podido leer un precio comparable. Volveremos a intentarlo.',network:'La tienda no respondió. Volveremos a intentarlo.',unavailable:'La variante no aparece disponible. Conservamos la última lectura válida.',changed:'El producto ha cambiado. Desactiva y vuelve a configurar la alerta.',cooldown:'Espera unos minutos antes de volver a comprobar.',stale:'La lectura ha caducado. Vuelve a leer el precio antes de activar.',missing:'Este producto ya no está disponible en tu colección.',purchased:'Las alertas se detienen para los productos comprados.'};
export function errorText(code){return ERROR_TEXT[code]||'No se pudo completar la consulta. Inténtalo de nuevo.';}
export function createTracking(item, quote, mode, now=Date.now(), previous=null) {
  const ref=mode==='saved'?minor(item.price,item.currency):quote.minor;
  if(ref===null || quote.currency!==item.currency)throw new Error('currency');
  const tracking={version:1,id:item.id,url:item.url,enabled:true,generation:crypto.randomUUID(),key:quote.key,label:quote.label,currency:quote.currency,reference:ref,referencePrice:mode==='saved'?item.price:quote.price,referenceSource:mode==='saved'?'saved':'verified',referenceAt:mode==='saved'?(item.updatedAt||item.createdAt):new Date(now).toISOString(),activatedAt:now,status:'pending',lastNotified:null,lastCheckedAt:null,lastAttemptAt:null,nextCheckAt:now,history:previous?.history||[],events:previous?.events||[],failures:0};
  return applyQuote(tracking,quote,now);
}
export function applyQuote(track, quote, now=Date.now()) {
  if(quote.key!==track.key || quote.currency!==track.currency)throw new Error('changed');
  if(quote.available===false)throw new Error('unavailable');
  if(quote.minor!==minor(quote.price,quote.currency))throw new Error('unreadable');
  // A fall of 50% or more is re-read on a separate attempt at least 5 minutes later.
  const baseline=track.latest?.minor ?? track.reference;
  if(quote.minor < baseline*0.5 && !(track.candidate?.minor===quote.minor && now-track.candidate.at>=5*60000)) {
    return {...track,candidate:{minor:quote.minor,at:track.candidate?.minor===quote.minor?track.candidate.at:now},status:'confirming',lastAttemptAt:now,nextCheckAt:now+5*60000};
  }
  const latest={...quote,at:now};
  const history=[...track.history];
  if(history.at(-1)?.minor!==quote.minor || history.at(-1)?.key!==quote.key)history.push(latest);
  const threshold=Math.min(track.reference,track.lastNotified??Infinity);
  const events=[...track.events];
  const drop=quote.minor<threshold;
  if(drop)events.push({id:`${track.generation}:${quote.minor}`,at:now,price:quote.price,minor:quote.minor,currency:track.currency,referencePrice:track.referencePrice,read:false,delivery:'pending',attempts:0,nextDeliveryAt:now});
  return {...track,latest,history:history.slice(-180),events:events.slice(-100),lastNotified:drop?quote.minor:track.lastNotified,status:'active',error:null,candidate:null,lastCheckedAt:now,lastAttemptAt:now,nextCheckAt:now+DAY,failures:0};
}
export function failTracking(track, code, now=Date.now()) {
  const failures=(track.failures||0)+1;
  return {...track,status:code==='permission'?'permission':'error',error:code,failures,lastAttemptAt:now,nextCheckAt:now+Math.min(DAY,30*60000*2**Math.min(failures-1,5))};
}
export function effectiveItem(item,track) {
  if(!track?.latest || track.currency!==item.currency || track.url!==item.url || track.latest.at<Date.parse(item.updatedAt||item.createdAt||0))return item;
  // Discount capture is separate: never pair a new price with an old struck-out offer.
  return {...item,price:track.latest.price,originalPrice:null,discountCheckedAt:null};
}
