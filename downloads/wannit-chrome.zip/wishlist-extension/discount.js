// Self-contained injected reader. Compare prices only inside a product price block.
export function detectDiscount(price, currency) {
  const result = { originalPrice: null, checkedAt: new Date().toISOString(), sourceUrl: location.href };
  if (!Number.isFinite(price) || price < 0) return result;
  const visible = node => {
    if (!node || node.closest('[hidden],template')) return false;
    const style = getComputedStyle(node);
    return style.display !== 'none' && style.visibility !== 'hidden' && node.getClientRects().length > 0;
  };
  const amount = node => {
    if (!visible(node)) return null;
    const text = node.textContent.replace(/\s+/g, ' ').trim();
    // Require a currency and a single amount; reject instalments, ranges and coupons.
    const match = text.match(/^(€|EUR|USD|GBP|£|\$)?\s*((?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d{1,2})?)\s*(€|EUR|USD|GBP|£|\$)?$/);
    if (!match || (!match[1] && !match[3])) return null;
    const symbol = match[1] || match[3];
    const unit = ({ '€': 'EUR', '£': 'GBP', '$': 'USD' })[symbol] || symbol;
    if (unit !== currency) return null;
    let value = match[2].replace(/ /g, '');
    const decimal = value.match(/[.,]\d{1,2}$/);
    value = decimal ? value.slice(0, decimal.index).replace(/[.,]/g, '') + '.' + value.slice(decimal.index + 1) : value.replace(/[.,]/g, '');
    return Number(value);
  };
  const originals = new Set();
  const consider = (current, original) => {
    const a = amount(current), b = amount(original);
    if (a !== null && b !== null && Math.abs(a - price) < 0.005 && b > a) originals.add(b);
  };
  if (/(^|\.)nike\.com$/i.test(location.hostname)) {
    for (const current of document.querySelectorAll('[data-testid="currentPrice-container"]')) {
      consider(current, current.parentElement?.querySelector('[data-testid="initialPrice-container"]'));
    }
  }
  // Massimo Dutti uses custom components and a CSS strikethrough, not <del>.
  // Restrict to the product heading: recommendation cards can have other prices.
  if (/(^|\.)massimodutti\.com$/i.test(location.hostname)) {
    for (const block of document.querySelectorAll('.md-product-heading-prices product-prices')) {
      const current = Array.from(block.querySelectorAll('.d-price-special formatted-price-detail span[aria-label]')).filter(visible);
      const original = Array.from(block.querySelectorAll('formatted-price-detail span.is-through')).filter(visible);
      if (current.length === 1 && original.length === 1) consider(current[0], original[0]);
    }
  }
  // Generic fallback: a single current and crossed-out amount in a small product block.
  for (const original of document.querySelectorAll('del,s')) {
    if (!original.closest('[itemtype*="schema.org/Product"],.product-info,.product__info,.product-information')) continue;
    const block = original.parentElement;
    if (!block || block.textContent.length > 160 || block.querySelectorAll('del,s').length !== 1) continue;
    const current = Array.from(block.children).filter(node => node !== original && !node.querySelector('del,s') && amount(node) === price);
    if (current.length === 1) consider(current[0], original);
  }
  if (originals.size === 1) result.originalPrice = [...originals][0];
  return result;
}
