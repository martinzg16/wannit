import { api, readItems } from './store.js';
export const listName = value => String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ');
const identity = value => listName(value).toLocaleLowerCase('es');
export async function readLists() {
 const data = await api.storage.local.get(null);
 return Object.entries(data).filter(([key,value]) => key.startsWith('list:') && value?.id && typeof value.name === 'string').map(([,value])=>value).sort((a,b)=>a.createdAt.localeCompare(b.createdAt));
}
export async function createList(name) {
 name = listName(name);
 if (!name || name.length > 80) throw new Error('Escribe un nombre de entre 1 y 80 caracteres.');
 if ((await readLists()).some(list=>identity(list.name) === identity(name))) throw new Error('Ya tienes una lista con ese nombre.');
 const list = {id:crypto.randomUUID(),name,createdAt:new Date().toISOString()};
 await api.storage.local.set({['list:'+list.id]:list}); return list;
}
export async function renameList(id,name) {
 name=listName(name);
 if (!name || name.length>80) throw new Error('Escribe un nombre de entre 1 y 80 caracteres.');
 const lists=await readLists(), list=lists.find(list=>list.id===id);
 if(!list)throw new Error('Esta lista ya no está disponible.');
 if(lists.some(list=>list.id!==id && identity(list.name)===identity(name)))throw new Error('Ya tienes una lista con ese nombre.');
 const updated={...list,name,updatedAt:new Date().toISOString()};await api.storage.local.set({['list:'+id]:updated});return updated;
}
export async function moveItems(ids,listId) {
 const unique=[...new Set(ids)];
 if(!unique.length)throw new Error('Selecciona al menos un producto.');
 if(listId && !(await readLists()).some(list=>list.id===listId))throw new Error('Esta lista ya no está disponible.');
 const items=await readItems(), updates={};
 for(const id of unique){const item=items.find(item=>item.id===id);if(!item)throw new Error('Uno de los productos ya no está disponible.');updates['item:'+id]={...item,listId:listId||null,updatedAt:new Date().toISOString()};}
 await api.storage.local.set(updates);
}
export function listLabel(lists,id){return lists.find(list=>list.id===id)?.name || 'Sin lista';}
