// Self-contained: Chrome serializes this function to run in the active page.
export function detectFinancing() {
  const checkedAt = new Date().toISOString();
  const sourceUrl = location.href;
  const offers = [];
  const seen = new Set();
  const signal = /financia(?:ción|cion|r|do|da|ble)|paga(?:r)?\s+(?:en\s+\d+\s+(?:plazos|cuotas)|a\s+plazos)|\d+\s*(?:cuotas|plazos|installments)|\b(?:financing|buy now[ ,]+pay later|pay in \d+)\b|(?:€|EUR|USD|GBP|£|\$)\s*(?:\/|al\s+|por\s+)(?:mes|month)/i;
  const negative = /(?:no\s+(?:se\s+)?(?:ofrece(?:mos)?|admite|permite|disponible|puede|es\s+posible)|no\s+hay|sin\s+financia|sin\s+opci[oó]n|not\s+(?:available|eligible)|unavailable|no\s+financia)/i;
  const providers = /\b(?:Klarna|PayPal|Aplazame|Sequra|seQura|Cetelem|Cofidis|Oney|Affirm|Afterpay|Scalapay)\b/gi;
  const amount = '(?:\\d{1,3}(?:[., ]\\d{3})+|\\d+)(?:[.,]\\d{1,2})?\\s*(?:€|EUR|USD|GBP|£|\\$)';
  const rules = {
    installments: /\b\d{1,3}\s*(?:cuotas|plazos|installments|meses|months)\b|\bpay in \d{1,3}\b/i,
    installmentAmount: new RegExp('(?:desde\\s+)?' + amount + '\\s*(?:(?:\\/|al\\s+|por\\s+)(?:mes|month)|(?:por\\s+)?cuota)|(?:cuotas|plazos|installments)\\s+(?:de\\s+)?' + amount, 'i'),
    upfront: new RegExp('(?:entrada|pago inicial|down payment)\\s*(?:de|:)?\\s*' + amount, 'i'),
    interest: /(?:TAE|TIN|APR)\s*[:=]?\s*\d+(?:[.,]\d+)?\s*%|sin intereses|interest.free/i,
    total: new RegExp('(?:importe total adeudado|total a pagar|coste total|total repayable)\\s*(?:de|:)?\\s*' + amount, 'i')
  };
  const visible = node => {
    if (node.closest('[hidden],[aria-hidden="true"],script,style,noscript,template')) return false;
    const style = getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || !node.getClientRects().length) return false;
    for (let ancestor = node; ancestor; ancestor = ancestor.parentElement) {
      if (getComputedStyle(ancestor).opacity === '0') return false;
    }
    return true;
  };
  const normalize = value => (value || '').replace(/\s+/g, ' ').trim();
  const title = normalize(document.querySelector('h1')?.innerText).toLowerCase();
  // Small visible blocks retain local context; never scan script source or hidden copy.
  const nodes = document.querySelectorAll('p,li,a,button,span,div,klarna-placement');
  for (const node of Array.from(nodes).slice(0, 15000)) {
    if (offers.length >= 6) break;
    if (!visible(node)) continue;
    const text = normalize(node.innerText);
    if (!text || text.length > 650 || !signal.test(text) || negative.test(text)) continue;
    const surrounding = normalize(node.parentElement?.innerText);
    if (surrounding.length <= 650 && negative.test(surrounding)) continue;
    // Read the smallest meaningful block, avoiding repeated ancestor matches.
    if (Array.from(node.children).some(child => {
      const childText = normalize(child.innerText);
      return visible(child) && signal.test(childText) && !negative.test(childText);
    })) continue;
    if (seen.has(text.toLowerCase())) continue;
    seen.add(text.toLowerCase());
    const terms = {};
    for (const [key, regex] of Object.entries(rules)) terms[key] = text.match(regex)?.[0] || null;
    const generic = !!node.closest('header,footer,nav,[role="navigation"],[role="contentinfo"]');
    const scope = node.closest('[itemtype*="schema.org/Product"],[data-product-id],.product-info,.product__info,.product-information');
    const scopeHeading = normalize(scope?.querySelector('h1,h2,[itemprop="name"]')?.innerText).toLowerCase();
    const belongsToProduct = !!scope && !!title && scopeHeading === title;
    const explicitProduct = /(?:este (?:producto|art[ií]culo)|this (?:product|item))/i.test(text);
    const concrete = !!(terms.installments || terms.installmentAmount);
    const status = !generic && concrete && (belongsToProduct || (explicitProduct && node.closest('main'))) ? 'product' : 'store';
    const providerNames = [...new Set((text.match(providers) || []).map(name => name.toLowerCase()))];
    const provider = [...new Set(text.match(providers) || [])].join(', ') || null;
    const ambiguous = providerNames.length > 1 || Object.values(rules).some(regex => new Set(text.match(new RegExp(regex.source, 'gi')) || []).size > 1);
    if (ambiguous) for (const key of Object.keys(terms)) terms[key] = null;
    let conditionsUrl = sourceUrl;
    const anchor = node.closest('a[href]') || node.querySelector('a[href]');
    try { const u = new URL(anchor?.getAttribute('href') || sourceUrl, sourceUrl); if (/^https?:$/.test(u.protocol)) conditionsUrl = u.href; } catch {}
    offers.push({ status, provider, evidence: text, terms, conditionsUrl });
  }
  return { status: offers.some(offer => offer.status === 'product') ? 'product' : offers.length ? 'store' : 'not_detected', offers, sourceUrl, checkedAt };
}
