const paths = {
 heart: 'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z',
 bag: 'M5 7h14l1 14H4L5 7ZM8 8V6a4 4 0 0 1 8 0v2M9 12a3 3 0 0 0 6 0',
 box: 'm12 3 9 5-9 5-9-5 9-5ZM3 8v9l9 5 9-5V8M12 13v9M7.5 5.5l9 5',
 tag: 'M20 13 11 22 2 13V3h10l8 8v2ZM7 7h.01',
 laptop: 'M5 4h14v13H5V4ZM2 20h20l-3-3H5l-3 3Z',
 sparkle: 'm12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3 3-7Z',
 check: 'm5 12 4 4L19 6',
 trash: 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7',
 edit: 'm16 3 5 5-12 12-6 1 1-6L16 3ZM13 6l5 5',
 external: 'M14 3h7v7M21 3 10 14M10 3H3v18h18v-7',
 plus: 'M12 5v14M5 12h14',
 wallet: 'M3 5h17v15H3V5ZM3 9h17M15 13h5v4h-5v-4Z',
 coin: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM15 8h-5a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H9M12 5v14',
 down: 'm3 5 7 7 4-4 7 7M15 15h6V9',
 help: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM9 8a3 3 0 0 1 6 0c0 2-3 2-3 5M12 17h.01'
};
export function icon(name) {
 const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
 svg.setAttribute('viewBox','0 0 24 24'); svg.setAttribute('fill','none'); svg.setAttribute('stroke','currentColor'); svg.setAttribute('stroke-width','1.5'); svg.setAttribute('stroke-linecap','round'); svg.setAttribute('stroke-linejoin','round'); svg.setAttribute('aria-hidden','true'); svg.classList.add('icon');
 const path = document.createElementNS('http://www.w3.org/2000/svg','path'); path.setAttribute('d', paths[name] || paths.bag); svg.append(path); return svg;
}
export function categoryTheme(category) {
 if (['Ropa','Calzado','Accesorios'].includes(category)) return {tone:'peach',icon:'tag'};
 if (category==='Tecnología') return {tone:'lavender',icon:'laptop'};
 if (['Belleza','Deporte','Salud','Libros y ocio'].includes(category)) return {tone:'butter',icon:'sparkle'};
 return {tone:'mint',icon:'bag'};
}
