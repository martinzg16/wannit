// This function runs only after the user opens the extension on a page.
export function extractProduct() {
  const meta = (...names) => {
    for (const name of names) {
      const v = document.querySelector(`meta[property="${name}"],meta[name="${name}"]`)?.content;
      if (v) return v;
    }
    return '';
  };
  const products = [];
  const groups = [];
  function walk(value, group = null) {
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) { value.forEach(entry => walk(entry, group)); return; }
    const types = [].concat(value['@type'] || []);
    if (types.some(t => t === 'ProductGroup' || t === 'https://schema.org/ProductGroup')) {
      group = value; groups.push(value);
    }
    if (types.some(t => t === 'Product' || t === 'https://schema.org/Product')) products.push({ value, group });
    if (value.hasVariant) walk(value.hasVariant, group);
    if (value['@graph']) walk(value['@graph']);
    if (value.mainEntity) walk(value.mainEntity);
  }
  document.querySelectorAll('script[type="application/ld+json"]').forEach(script => { try { walk(JSON.parse(script.textContent)); } catch {} });
  // Ignore advertising parameters, but retain query parameters that may identify a variant.
  const identity = value => {
    try {
      const url = new URL(value, location.href); url.hash = '';
      for (const key of [...url.searchParams.keys()]) {
        if (/^(utm_.*|_gl|_ga|_gs|gclid|gclsrc|gbraid|wbraid|fbclid)$/i.test(key)) url.searchParams.delete(key);
      }
      url.searchParams.sort(); return url.href;
    } catch { return ''; }
  };
  const current = identity(location.href);
  const matches = products.filter(({ value }) => [value.url, value['@id'], ...[].concat(value.offers || []).map(o => o.url)].filter(Boolean).some(url => identity(url) === current));
  // Group variants must match the page. Never take the first color/size blindly.
  const candidates = matches.length ? matches : products.filter(entry => !entry.group);
  const selected = candidates[0];
  const product = selected?.value || {};
  const group = selected?.group || (groups.length === 1 ? groups[0] : null);
  const offer = [].concat(product.offers || [])[0] || {};
  const parsePrice = amount => {
    if (amount === '' || amount == null) return null;
    const n = Number(String(amount).replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? n : null;
  };
  let parsed = parsePrice(offer.price ?? meta('product:price:amount', 'og:price:amount'));
  const currency = offer.priceCurrency || meta('product:price:currency', 'og:price:currency') || 'EUR';
  if (selected?.group) {
    const quotes = candidates.flatMap(({ value }) => [].concat(value.offers || [{}])).map(o => ({ price: parsePrice(o.price), currency: o.priceCurrency || '' }));
    if (quotes.some(q => q.price === null || q.price !== parsed || q.currency !== currency)) parsed = null;
  }
  // Reject malformed schemes before URL() silently treats them as relative paths.
  // Try every product image, then secure/social metadata published by the page.
  const imageUrl = value => {
    if (typeof value !== 'string' || !value.trim()) return '';
    const raw = value.trim();
    if (/^[a-z][a-z0-9+.-]*:/i.test(raw) && !/^https?:\/\/[^/\s]/i.test(raw)) return '';
    try {
      const url = new URL(raw, location.href);
      return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  };
  const imageCandidates = [].concat(product.image || []).flatMap(value =>
    value && typeof value === 'object' ? [value.url, value.contentUrl] : [value]);
  imageCandidates.push(meta('og:image:secure_url'), meta('og:image'), meta('twitter:image'));
  const image = imageCandidates.map(imageUrl).find(Boolean) || '';
  return {
    title: group?.name || product.name || meta('og:title', 'twitter:title') || document.title,
    price: Number.isFinite(parsed) && parsed >= 0 ? parsed : null,
    categoryHint: typeof (product.category || group?.category) === 'string' ? (product.category || group?.category) : '',
    currency,
    url: location.href, image,
    multiple: candidates.length > 1 && (!selected?.group || parsed === null)
  };
}
