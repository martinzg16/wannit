import {api,money,safeUrl} from './store.js';
import {shopFor,minor} from './alert-readers.js';
import {errorText} from './alert-core.js';
import {openDialog} from './motion.js';
export const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
export async function alertCall(action,data={}) {
  const response=await api.runtime.sendMessage({target:'wannit-alerts',action,...data});
  if(!response?.ok)throw new Error(response?.message||'Recarga la extensión para activar el seguimiento.');
  return response.value;
}
export async function readTracking(){const data=await api.storage.local.get(null);return Object.fromEntries(Object.entries(data).filter(([k])=>k.startsWith('tracking:')).map(([,t])=>[t.id,t]));}
export const when=time=>time?new Date(time).toLocaleString('es-ES',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'Todavía sin comprobar';
export function trackingLabel(t,item) {
  if(item.purchased)return 'Pausada · producto comprado';
  if(!t?.enabled)return 'Alerta desactivada';
  if(t.status==='permission')return 'Falta permiso de la tienda';
  if(t.status==='error')return 'Sin actualizar';
  if(t.status==='confirming')return 'Confirmando una bajada';
  if(t.status==='pending')return 'Pendiente de comprobar';
  return 'Alerta activa';
}
function button(text,fn,cls='secondary'){const b=node('button',text,cls);b.type='button';b.onclick=fn;return b;}
async function permissionFor(item){const shop=shopFor(item.url);if(!shop)throw new Error(errorText('unsupported'));const allowed=await api.permissions.request({origins:[shop.origin]});if(!allowed)throw new Error(errorText('permission'));}
export async function configureAlert(item,onPlan) {
  // Keep request() directly on the click's user gesture.
  const permission=permissionFor(item);
  const dialog=node('dialog',undefined,'alert-config');dialog.setAttribute('aria-labelledby','alert-config-title');
  const close=button('Cerrar ×',()=>dialog.close(),'secondary alert-close');close.setAttribute('aria-label','Cerrar configuración de alerta');
  const eyebrow=node('p','QUE NO SE TE ESCAPE','eyebrow'),title=node('h2','AVÍSAME SI BAJA');title.id='alert-config-title';
  const name=node('p',item.title,'alert-product-name');
  const message=node('p','Solicitando acceso a la tienda…','hint');message.setAttribute('role','status');
  const content=node('div',undefined,'alert-config-body');
  dialog.append(close,eyebrow,title,name,message,content);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});openDialog(dialog);
  try {
    await permission;
    if(!dialog.open)return;
    message.textContent='Leyendo el precio de la tienda…';
    const result=await alertCall('probe',{url:item.url,currency:item.currency});
    if(!dialog.open)return;
    message.textContent='Elige qué quieres seguir y el precio desde el que te avisaremos.';
    const field=node('label','Variante');const select=node('select');select.setAttribute('aria-label','Variante para seguir');
    if(result.quotes.length>1){const first=node('option','Elige tu talla');first.value='';select.append(first);}
    for(const q of result.quotes){const o=node('option',`${q.label} · ${money(q.price,q.currency)}`);o.value=q.key;select.append(o);}
    field.append(select);content.append(field);
    const ref=node('div',undefined,'alert-reference-choice');
    const freshLabel=node('label',undefined,'alert-radio'),fresh=node('input');fresh.type='radio';fresh.name='referenceMode';fresh.value='fresh';fresh.checked=true;
    const freshText=node('span','Usar el precio recién leído');freshLabel.append(fresh,freshText);
    const savedLabel=node('label',undefined,'alert-radio'),saved=node('input');saved.type='radio';saved.name='referenceMode';saved.value='saved';saved.disabled=minor(item.price,item.currency)===null;
    savedLabel.append(saved,node('span',`Usar ${money(item.price,item.currency)} de mi guardado`));
    ref.append(freshLabel,savedLabel,node('p',`Precio guardado: ${when(item.updatedAt||item.createdAt)}. Puede haber cambiado.`, 'hint'));
    content.append(ref);
    const note=node('p','Una comprobación diaria mientras Chrome esté abierto. Sin costes de envío ni cupones. La disponibilidad se confirma en la tienda.','hint');content.append(note);
    const submit=button(onPlan?'Activar al guardar':'Activar alerta',async()=>{
      if(!select.value){message.textContent='Elige la talla o variante que quieres seguir.';select.focus();return;}
      submit.disabled=true;
      try{
        const plan={token:result.token,key:select.value,mode:saved.checked?'saved':'fresh'};
        if(onPlan)await onPlan(plan);else await alertCall('enable',{id:item.id,...plan});
        dialog.close();
      }catch(error){message.textContent=error.message;submit.disabled=false;}
    },'primary');content.append(submit);
  }catch(error){message.textContent=error.message;content.append(node('p','Puedes guardar el producto sin alerta y volver a intentarlo desde su detalle.','hint'));}
}
export function mountAlertControl(container,item,{track=null,getItem=()=>item,onPlan=null,planned=false,history=false}={}) {
  const box=node('section',undefined,'alert-control');box.classList.toggle('is-active',Boolean(track?.enabled)||planned);
  const head=node('div',undefined,'alert-control-head'),copy=node('div');copy.append(node('strong','Avísame si baja'),node('p',planned?'Se activará cuando guardes':trackingLabel(track,item),'hint'));
  const toggle=button('',async()=>{
    if(onPlan && planned){await onPlan(null);return;}
    if(track?.enabled){toggle.disabled=true;try{await alertCall('disable',{id:item.id});mountAlertControl(container,item,{...argumentsOptions(),track:{...track,enabled:false}});}catch(error){status.textContent=error.message;toggle.disabled=false;}return;}
    await configureAlert(getItem(),onPlan);
  },'alert-switch');
  const argumentsOptions=()=>({getItem,onPlan,planned:false,history});
  toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(Boolean(track?.enabled)||planned));toggle.setAttribute('aria-label',`Avísame si baja: ${item.title}`);toggle.append(node('span'));
  const supported=Boolean(shopFor(item.url));toggle.disabled=!supported||item.purchased;
  head.append(copy,toggle);box.append(head);
  const status=node('p',undefined,'hint alert-status');status.setAttribute('role','status');box.append(status);
  if(!supported)status.textContent='Esta tienda aún no admite alertas. Por ahora: Nike España y Everyday Better Club.';
  else if(item.purchased)status.textContent='Vuelve a pendientes para activar una nueva alerta.';
  else if(track?.enabled){
    status.textContent=track.error?errorText(track.error):track.status==='confirming'?'Volveremos a leer esta bajada antes de avisarte.':`Última comprobación: ${when(track.lastCheckedAt)}.`;
    const facts=node('div',undefined,'alert-facts');
    for(const [label,value] of [['Referencia',money(track.referencePrice,track.currency)],['Último aviso',track.lastNotified===null?'—':money(track.events.filter(e=>e.currency===track.currency).at(-1)?.price,track.currency)]]){const fact=node('div');fact.append(node('span',label),node('strong',value));facts.append(fact);}
    box.append(facts,node('p',track.label,'hint'));
    const actions=node('div',undefined,'alert-control-actions');
    if(track.status==='permission')actions.append(button('Volver a dar permiso',async()=>{try{await permissionFor(item);await alertCall('resume',{id:item.id});status.textContent='Permiso concedido. Comprobaremos el precio en breve.';}catch(e){status.textContent=e.message;}}));
    else actions.append(button('Comprobar ahora',async event=>{const b=event.currentTarget;b.disabled=true;status.textContent='Consultando la tienda…';try{await alertCall('check',{id:item.id});const tracks=await readTracking();mountAlertControl(container,item,{...argumentsOptions(),track:tracks[item.id]});}catch(e){status.textContent=e.message;}finally{b.disabled=false;}}));
    box.append(actions);
  }else if(supported)status.textContent=planned?'El permiso de la tienda está listo.':'Una comprobación diaria mientras Chrome esté abierto.';
  if(history && track?.history?.length){
    const details=node('details',undefined,'alert-history');details.append(node('summary','Historial de precios'));
    const rows=node('ol');
    for(const q of [...track.history].reverse().slice(0,30)){const row=node('li');row.append(node('time',when(q.at)),node('strong',money(q.price,q.currency)),node('span',q.label));rows.append(row);}
    details.append(rows,node('p','Solo lecturas de la tienda. Las ediciones manuales se guardan aparte.','hint'));box.append(details);
  }
  container.replaceChildren(box);
}
export function cardAlert(item,track){
  const wrap=node('div',undefined,'card-alert');
  if(!track?.enabled)return wrap;
  const dropped=track.latest?.minor<track.reference;
  wrap.append(node('span',dropped?`↓ ${money(track.referencePrice-track.latest.price,track.currency)} desde tu referencia`:trackingLabel(track,item),dropped?'alert-pill is-drop':'alert-pill'));
  wrap.append(node('span',track.status==='active'?`Comprobado ${when(track.lastCheckedAt)}`:trackingLabel(track,item),'hint'));
  return wrap;
}
export async function openInbox(items,tracks) {
  const dialog=node('dialog',undefined,'alert-inbox');dialog.setAttribute('aria-labelledby','alert-inbox-title');
  const close=button('Cerrar ×',()=>dialog.close(),'secondary alert-close');
  const title=node('h2','TUS BAJADAS');title.id='alert-inbox-title';
  const status=node('p','Las bajadas se quedan aquí, aunque no actives las notificaciones del sistema.','hint');status.setAttribute('role','status');
  dialog.append(close,node('p','BUENAS NOTICIAS PARA TU WISHLIST','eyebrow'),title,status);
  const permission=await api.permissions.contains({permissions:['notifications']});
  if(!permission)dialog.append(button('Activar notificaciones del sistema',async event=>{const b=event.currentTarget;try{const ok=await api.permissions.request({permissions:['notifications']});status.textContent=ok?'Notificaciones activadas. Los avisos pendientes se enviarán en breve.':'Puedes seguir consultando las bajadas aquí.';if(ok)b.remove();}catch{status.textContent='No se pudieron activar. Revisa los permisos de Chrome.';}}));
  else if(!api.notifications || await api.notifications.getPermissionLevel()!=='granted')dialog.append(node('p','El sistema está bloqueando las notificaciones de Chrome. Puedes habilitarlas en sus ajustes.','hint'));
  const events=Object.values(tracks).flatMap(t=>t.events.map(e=>({...e,item:items.find(i=>i.id===t.id),trackId:t.id}))).filter(e=>e.item).sort((a,b)=>b.at-a.at);
  const list=node('div',undefined,'inbox-list');
  if(!events.length)list.append(node('div','Todavía no hay bajadas. Activa una alerta en el detalle de un producto para empezar.','alert-empty'));
  for(const e of events){
    const row=node('article',undefined,'inbox-event');row.classList.toggle('unread',!e.read);
    const top=node('div',undefined,'inbox-event-top');top.append(node('span',e.read?'Leído':'Nuevo','alert-pill'),node('time',when(e.at),'hint'));
    const name=node('h3',e.item.title),amount=node('p',money(e.price,e.currency),'inbox-price');
    const ref=node('p',`${money(e.referencePrice-e.price,e.currency)} menos que tu referencia de ${money(e.referencePrice,e.currency)}.`,'hint');
    const link=node('a','Ver producto ↗','shop');link.href=safeUrl(e.item.url);link.target='_blank';link.rel='noopener noreferrer';
    const mark=()=>alertCall('read',{id:e.trackId,eventId:e.id}).then(()=>{row.classList.remove('unread');top.firstChild.textContent='Leído';}).catch(()=>{status.textContent='No se pudo marcar como leído.';});link.onclick=mark;
    row.append(top,name,amount,ref,link);
    if(!e.read)row.append(button('Marcar como leído',async event=>{const b=event.currentTarget;await mark();b.remove();},'text-button'));
    list.append(row);
  }
  dialog.append(list);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});openDialog(dialog);
}
