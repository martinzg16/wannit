// Strict, bundled readers. No remote scripts are executed.
export const SHOPS = ['Nike España', 'Everyday Better Club'];
export function shopFor(value) {
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:' || u.username || u.password || u.port) return null;
    for (const k of [...u.searchParams.keys()]) if (/^(utm_.*|_gl|_ga|_gs|gclid|gclsrc|gbraid|wbraid|fbclid|msockid)$/i.test(k)) u.searchParams.delete(k);
    u.hash = '';
    if (u.hostname === 'www.nike.com' && /^\/es\/t\/[^/]+\/[A-Z0-9]+-\d{3}\/?$/i.test(u.pathname) && !u.search) {
      return {id:'nike-es', name:SHOPS[0], url:u.href, origin:u.origin+'/*', product:u.pathname.split('/').filter(Boolean).at(-1).toUpperCase(), market:'ES'};
    }
    if (u.hostname === 'everydaybetterclub.com' && /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?products\/[a-z0-9-]+\/?$/i.test(u.pathname) && [...u.searchParams.keys()].every(k=>['variant','currency','country'].includes(k))) {
      u.searchParams.sort();
      return {id:'ebc', name:SHOPS[1], url:u.href, origin:u.origin+'/*', product:u.pathname.replace(/\/$/,''), variant:u.searchParams.get('variant'), market:[u.pathname.split('/products/')[0],u.searchParams.get('country')||'default'].join(':')};
    }
  } catch {}
  return null;
}
export function minor(value, currency) {
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  if (!/^[A-Z]{3}$/.test(currency || '') || !/^\d+(?:\.\d+)?$/.test(String(value))) return null;
  try {
    const digits = new Intl.NumberFormat('en',{style:'currency',currency}).resolvedOptions().maximumFractionDigits;
    const amount = Number(value) * 10 ** digits;
    return amount > 0 && Number.isSafeInteger(Math.round(amount)) && Math.abs(amount-Math.round(amount)) < 0.00001 ? Math.round(amount) : null;
  } catch { return null; }
}
const typeIs = (v,type)=>[].concat(v?.['@type']||[]).some(t=>t===type || t===`https://schema.org/${type}` || t===`http://schema.org/${type}`);
export function readQuotes(blocks, url) {
  const shop=shopFor(url);
  if(!shop)throw new Error('unsupported');
  const products=[];
  function walk(v) {
    if(!v || typeof v!=='object')return;
    if(Array.isArray(v)){v.forEach(walk);return;}
    if(typeIs(v,'Product'))products.push(v);
    for(const key of ['@graph','hasVariant','mainEntity'])if(v[key])walk(v[key]);
  }
  blocks.forEach(walk);
  let quotes=[];
  for(const p of products) {
    const before=quotes.length;
    for(const o of [].concat(p.offers||[])) {
      if(!typeIs(o,'Offer') || o.priceSpecification || o.validForMemberTier || o.eligibleQuantity || o.eligibleCustomerType || o.addOn)continue;
      if(o.priceValidUntil && Date.parse(o.priceValidUntil+'T23:59:59Z') < Date.now())continue;
      let offerUrl;try{offerUrl=new URL(o.url||p.url,url);}catch{continue;}
      const offered=shopFor(offerUrl.href);
      if(!offered || offered.id!==shop.id || offered.product!==shop.product || offered.market!==shop.market)continue;
      const currency=o.priceCurrency, cents=minor(o.price,currency);
      if(cents===null)continue;
      let variant, label;
      if(shop.id==='nike-es') {
        if(String(p.mpn).toUpperCase()!==shop.product || !p.size || !(p.gtin||p.sku))continue;
        variant=String(p.gtin||p.sku);label=`${p.color||shop.product} · Talla ${p.size}`;
      } else {
        variant=offerUrl.searchParams.get('variant');
        if(!variant || (shop.variant && variant!==shop.variant))continue;
        label=`Variante del enlace · ${o.sku||variant}`;
      }
      const availability=String(o.availability||'').split('/').at(-1);
      quotes.push({key:[shop.id,shop.product,shop.market,variant,currency].join('|'),variant,label,currency,price:Number(o.price),minor:cents,available:availability ? availability==='InStock' : null,sourceUrl:shop.url,shop:shop.name,title:String(p.name||shop.name).slice(0,250)});
    }
    if(shop.id==='ebc' && !shop.variant && shopFor(p.url)?.product===shop.product && quotes.length-before!==[].concat(p.offers||[]).length)throw new Error('variant');
  }
  // A bare EBC product URL follows only a price shared by ALL published variants.
  if(shop.id==='ebc' && !shop.variant && quotes.length) {
    if(new Set(quotes.map(q=>`${q.minor}|${q.currency}`)).size!==1)throw new Error('variant');
    const q=quotes[0];
    quotes=[{...q,key:[shop.id,shop.product,shop.market,'all-uniform',q.currency].join('|'),variant:'all-uniform',label:'Precio común a todas las variantes',available:quotes.some(q=>q.available===true)?true:quotes.every(q=>q.available===false)?false:null}];
  }
  const unique=new Map();
  for(const q of quotes) {
    if(unique.has(q.key) && (unique.get(q.key).minor!==q.minor || unique.get(q.key).available!==q.available))throw new Error('ambiguous');
    unique.set(q.key,q);
  }
  if(!unique.size)throw new Error('unreadable');
  return [...unique.values()];
}
// JSON-LD scripts are data; parsing them requires neither a page DOM nor remote code.
export function readHTML(html,url) {
  const blocks=[];
  for(const [,attrs,body] of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
    if(!/\btype\s*=\s*["']application\/ld\+json["']/i.test(attrs))continue;
    try{blocks.push(JSON.parse(body));}catch{}
  }
  const quotes=readQuotes(blocks,url);
  if(shopFor(url)?.id==='ebc') {
    const markets=[...new Set([...html.matchAll(/\bShopify\.country\s*=\s*["']([A-Z]{2})["']/g)].map(m=>m[1]))];
    if(markets.length!==1)throw new Error('unreadable');
    return quotes.map(q=>({...q,key:q.key+'|market:'+markets[0],market:markets[0]}));
  }
  return quotes;

}
